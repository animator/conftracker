# Design System Strategy: The Editorial Curator

## 1. Overview & Creative North Star: The Editorial Curator
This design system moves away from the rigid, boxy constraints of traditional news aggregates. Our Creative North Star is **"The Editorial Curator"**—a philosophy that treats digital space with the same reverence as a high-end print broadsheet, while utilizing the fluid depth of modern interface technology.

We reject the "template" look. Instead of a flat grid of uniform boxes, we employ **intentional asymmetry** and **tonal layering**. By utilizing wide `16` (5.5rem) and `20` (7rem) spacing values, we allow headlines to breathe, creating a sense of authoritative calm. The experience should feel like a series of "composed" moments rather than a cluttered feed.

## 2. Colors & Surface Architecture
The palette is rooted in `surface` (#f7f9fb) and `secondary` (#526074) tones, creating a professional, slate-gray foundation that feels more sophisticated than pure neutral grays.

### The "No-Line" Rule
Standard 1px solid borders are prohibited for sectioning. Structural boundaries must be defined solely through background color shifts. For instance, a "Breaking News" sidebar should be rendered in `surface-container-low` (#f0f4f7) sitting against the main `surface` (#f7f9fb) background. This creates "soft boundaries" that guide the eye without visual clutter.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of fine paper.
- **Level 0 (Base):** `surface` (#f7f9fb) for the main viewport.
- **Level 1 (Sections):** `surface-container-low` (#f0f4f7) for large content areas.
- **Level 2 (Feature Cards):** `surface-container-lowest` (#ffffff) to provide a crisp, "lifted" feel for high-priority articles.

### The "Glass & Gradient" Rule
To add visual "soul," use Glassmorphism for floating navigation bars or weather widgets. Utilize `surface-container-lowest` at 80% opacity with a `backdrop-blur` of 12px. For primary CTAs (like "Subscribe"), use a subtle linear gradient transitioning from `primary` (#0256d2) to `primary-container` (#4880fd) at a 135-degree angle.

## 3. Typography: The Intellectual Contrast
We use a high-contrast pairing to establish an immediate hierarchy of "News" vs. "Utility."

- **The Voice (Serif):** `newsreader` is our editorial engine. Use `display-lg` (3.5rem) for investigative long-form headers and `headline-md` (1.75rem) for standard news cards. The serif choice signals trust and legacy.
- **The Engine (Sans-Serif):** `inter` provides the functional framework. All `body` and `label` styles use Inter to ensure maximum legibility at small scales.
- **Micro-Copy:** Use `label-md` in `on-surface-variant` (#596064) with a `0.05em` letter-spacing for category tags (e.g., "POLITICS," "ECONOMY") to create a modern, rhythmic texture.

## 4. Elevation & Depth
Hierarchy is achieved through **Tonal Layering** rather than drop shadows.

- **The Layering Principle:** Avoid `elevation-1` shadows. Instead, place a `surface-container-lowest` card on a `surface-dim` background. This "tonal lift" creates a more premium, architectural feel.
- **Ambient Shadows:** If a card must float (e.g., a newsletter pop-up), use a shadow with a 40px blur, 0px spread, and 6% opacity, tinted with `on-surface` (#2c3437).
- **The "Ghost Border" Fallback:** For accessibility in input fields, use the `outline-variant` (#acb3b7) at 20% opacity. Never use 100% opaque outlines.

## 5. Components

### Cards & News Feed
*   **Structure:** No divider lines. Use `spacing-6` (2rem) of vertical whitespace to separate articles.
*   **Interaction:** On hover, a card should shift from `surface` to `surface-container-high` (#e3e9ed) with a 200ms ease-in-out transition.

### Buttons
*   **Primary:** Gradient of `primary` to `primary-container`. `rounded-md` (0.375rem). Text in `on-primary`.
*   **Tertiary (Text Link):** Use `primary` (#0256d2) for the text color. No underline by default; add a 2px underline from `primary-fixed-dim` on hover.

### Chips (Category Tags)
*   **Style:** `surface-container-highest` (#dce4e8) background with `on-surface-variant` text.
*   **Shape:** `rounded-full` for a modern, pill-like "curated" look.

### Input Fields
*   **Style:** `surface-container-lowest` background with a `ghost border`.
*   **States:** On focus, the border transitions to `primary` (#0256d2) at 50% opacity with a subtle 4px "outer glow" using the `primary-fixed` token.

### Editorial Quote Block (Contextual Component)
*   **Style:** Large `headline-sm` serif text. Instead of a left-border, use a subtle `surface-variant` (#dce4e8) background fill with `spacing-8` (2.75rem) horizontal padding to "cradle" the insight.

## 6. Do’s and Don’ts

### Do:
*   **Do** use `display-lg` for top-tier investigative stories to create a "Front Page" impact.
*   **Do** embrace asymmetry. Align some images to the right and others to the left to break the "WordPress" feel.
*   **Do** use `on-secondary-container` (#455367) for sub-headlines to reduce visual weight compared to the main title.

### Don’t:
*   **Don't** use black (#000000) for text. Use `on-surface` (#2c3437) to maintain a soft, ink-on-paper reading experience.
*   **Don't** use 1px dividers between list items. Use the spacing scale (`spacing-4`) and background tonal shifts.
*   **Don't** use "pure" blue for links; stick to the `primary` (#0256d2) token to ensure professional brand alignment.