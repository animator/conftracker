import asyncio
import sys
sys.path.append('src')

from scrapers.base import BaseScraper
from bs4 import BeautifulSoup
import requests

class DummyScraper(BaseScraper):
    source_name = "test"
    def discover_article_urls(self):
        return []

scraper = DummyScraper()
url = "https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro"

# test fetch_rendered
print("Fetching via requests...")
resp = scraper.fetch(url)
html = resp.text
article = scraper._parse_html(url, html)

print(f"Title: {article.title}")
print(f"Desc: {article.description}")
print(f"Body length: {len(article.body)}")
print(f"Body preview: {article.body[:100]}")
