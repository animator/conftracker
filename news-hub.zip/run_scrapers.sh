#!/bin/bash
# run_scrapers.sh
# Usage: ./run_scrapers.sh [hourly|daily|weekly|all]

# Move to the directory where the script is located
cd "$(dirname "$0")"

# Activate virtual environment if it exists
if [ -f ".venv/bin/activate" ]; then
    source .venv/bin/activate
fi

FREQUENCY=$1

# Group scrapers by ideal frequency based on feed analysis
HOURLY_SCRAPERS=("techcrunch" "theverge" "venturebeat" "infoq" "mashable")
DAILY_SCRAPERS=("analyticsindiamag" "arxiv" "github" "huggingface" "marktechpost" "opensourceforu" "cxodigitalpulse" "cio_elets")
WEEKLY_SCRAPERS=("google_blog" "nvidia_blog" "google_research" "ibm_research" "amazon_science" "stanford_ai" "cmu_ml" "huggingface_blog")

run_scraper() {
    local source=$1
    echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Running scraper: $source"
    news-hub run-source "$source" 2>/dev/null || python src/main.py run-source "$source"
}

if [ "$FREQUENCY" = "hourly" ]; then
    for s in "${HOURLY_SCRAPERS[@]}"; do run_scraper "$s"; done
elif [ "$FREQUENCY" = "daily" ]; then
    for s in "${DAILY_SCRAPERS[@]}"; do run_scraper "$s"; done
elif [ "$FREQUENCY" = "weekly" ]; then
    for s in "${WEEKLY_SCRAPERS[@]}"; do run_scraper "$s"; done
elif [ "$FREQUENCY" = "all" ]; then
    echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Running all scrapers"
    news-hub run 2>/dev/null || python src/main.py run
else
    echo "Usage: $0 [hourly|daily|weekly|all]"
    exit 1
fi
