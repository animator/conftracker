# Daily News Scraper

## 1. Overview

A cron-based web scraper that collects daily AI/tech news articles from curated sources and stores them in MongoDB. The scraper runs on a configurable schedule, deduplicates articles, and provides a clean data layer for downstream consumption (API, dashboard, newsletter, etc.).

## 2. Target Sources

| #   | Source URL                    | Content Focus                         |
| --- | ----------------------------- | ------------------------------------- |
| 1   | https://analyticsindiamag.com |                                       |
| 2   | https://export.arxiv.org/     | Research papers (cs.AI, cs.LG, cs.CL) |
| 3   | https://blog.google           |                                       |
| 4   | https://blogs.nvidia.com      |                                       |
| 5   | https://infoq.com             |                                       |
| 6   | https://mashable.com          |                                       |
| 7   | https://venturebeat.com       |                                       |
| 8   | https://techcrunch.com        |                                       |
| 9   | https://www.theverge.com      |                                       |

---

## 3. Functional Requirements

### 3.1 Scraping

- **FR-1**: The system shall scrape each target source on a configurable cron schedule (default: every 2 hours).
- **FR-2**: For each source, try to locate the sitemap or feed which can be used as a source.
- **FR-3**: For each source, extract at minimum: **title**, **URL**,**author**, **tags/categories**, **published date**, **og-image as bytes with mimetype**, **full article body**, **description**, and **source name**.
- **FR-4**: Use JSON-LD information or website content.
- **FR-5**: For arxiv, use the public Atom/RSS feed (`https://export.arxiv.org/rss/cs.AI`, etc.) instead of HTML scraping.
- **FR-6**: Each source shall have its own scraper module to isolate parsing logic.
- **FR-7**: Derive a unique key from the url and use it as a point of reference to scrape only the news that has not been scraped.

### 3.3 Storage

- **FR-8**: Prepare individual mongo collection for each source.
- **FR-9**: Each article document shall include a `scrapedAt` timestamp and a `status` field to denote if any error occurred in scraping.
- **FR-10**: The system shall maintain a `scrape_runs` collection to log each scrape execution (start time, end time, source, articles found, articles inserted, errors).

### 3.4 Scheduling & Execution

- **FR-11**: The cron schedule shall be configurable via environment variable (`SCRAPE_CRON`).
- **FR-12**: The system shall support a manual trigger mode (CLI command) to run scraping on demand outside the cron schedule.
- **FR-13**: Each source shall be scraped independently so that a failure in one source does not block others.

### 3.5 Error Handling & Resilience

- **FR-14**: On transient failure (network timeout, 5xx), retry up to 3 times with exponential backoff.
- **FR-15**: On persistent failure, log the error and continue with the remaining sources.
- **FR-16**: Rate-limit requests to each source (minimum 2-second delay between requests to the same domain).

---

## 4. Non-Functional Requirements

| ID    | Requirement                                                                                                                                     |
| ----- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| NFR-1 | **Performance**: Complete a full scrape cycle across all sources within 10 minutes.                                                             |
| NFR-2 | **Reliability**: The scraper must recover gracefully from crashes; partial runs should not corrupt data.                                        |
| NFR-3 | **Observability**: Structured logging (JSON) with log levels (info, warn, error).                                                               |
| NFR-4 | **Security**: No credentials in source code; use environment variables or a `.env` file. MongoDB connection string must support authentication. |
| NFR-5 | **Maintainability**: Adding a new source should require only adding a new scraper module and registering it — no changes to core logic.         |
| NFR-6 | **Cross-platform**: Should be able to run on both WIndows and macOS.                                                                            |
