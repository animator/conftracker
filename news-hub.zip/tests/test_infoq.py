from scrapers.infoq import InfoQScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/">
  <channel>
    <item>
      <title>AdonisJS v7 Ships End-to-End Type Safety, Reworked Starter Kits and Zero-Config OpenTelemetry</title>
      <link>https://www.infoq.com/news/2026/05/adonis-v7-opentelemetry/?utm_campaign=infoq_content&amp;utm_source=infoq&amp;utm_medium=feed&amp;utm_term=global</link>
      <description><img src="https://res.infoq.com/news/2026/05/adonis-v7-opentelemetry/en/headerimage/generatedHeaderImage-1778574705638.jpg"/><p>AdonisJS version 7 introduces end-to-end type safety and reworked starter kits, alongside improved documentation. The release includes 45+ updated packages and three new ones for OpenTelemetry, typed content. It requires Node.js 24, allowing the use of native APIs. The framework emphasizes a convention-over-configuration approach while offering tools for routing, ORM, and authentication.</p> <i>By Daniel Curtis</i></description>
      <category>Web Development</category>
      <category>Node.js</category>
      <category>TypeScript</category>
      <category>OpenTelemetry</category>
      <category>Development</category>
      <category>news</category>
      <pubDate>Tue, 12 May 2026 11:26:00 GMT</pubDate>
      <guid>https://www.infoq.com/news/2026/05/adonis-v7-opentelemetry/?utm_campaign=infoq_content&amp;utm_source=infoq&amp;utm_medium=feed&amp;utm_term=global</guid>
      <dc:creator>Daniel Curtis</dc:creator>
      <dc:date>2026-05-12T11:26:00Z</dc:date>
      <dc:identifier>/news/2026/05/adonis-v7-opentelemetry/en</dc:identifier>
    </item>
  </channel>
</rss>
"""

SAMPLE_ARTICLE_HTML = """<html>
  <body>
    <div class="article__data">
      <p>AdonisJS, the ‘batteries-included Node.js framework’ maintained by Harminder Virk, has released version 7 with end-to-end type safety as its headline feature, alongside reworked starter kits, zero-configuration observability, and a completely rebuilt documentation site.</p>
      <p>The release, which lands with 45+ updated packages and introduces three new ones: @adonisjs/otel for OpenTelemetry integration, @adonisjs/content for typed content collections, and edge-markdown for rendering Markdown with component syntax inside Edge templates.</p>
      <blockquote>The sweet spot for TypeScript-first backend work right now</blockquote>
      <div class="author-section-full">About the Author Daniel Curtis Show more Show less</div>
    </div>
  </body>
</html>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class InfoQScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_metadata_and_page_body(self) -> None:
        scraper = InfoQScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://www.infoq.com/news/2026/05/adonis-v7-opentelemetry/?utm_campaign=infoq_content&utm_source=infoq&utm_medium=feed&utm_term=global":
                return _FakeResponse(text=SAMPLE_ARTICLE_HTML)
            if url == "https://res.infoq.com/news/2026/05/adonis-v7-opentelemetry/en/headerimage/generatedHeaderImage-1778574705638.jpg":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/jpeg"},
                )
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.title,
            "AdonisJS v7 Ships End-to-End Type Safety, Reworked Starter Kits and Zero-Config OpenTelemetry",
        )
        self.assertEqual(article.author, "Daniel Curtis")
        self.assertEqual(
            article.tags,
            [
                "Web Development",
                "Node.js",
                "TypeScript",
                "OpenTelemetry",
                "Development",
                "news",
            ],
        )
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 12, 11, 26, 0, tzinfo=timezone.utc),
        )
        self.assertEqual(
            article.description,
            "AdonisJS version 7 introduces end-to-end type safety and reworked starter kits, alongside improved documentation. The release includes 45+ updated packages and three new ones for OpenTelemetry, typed content. It requires Node.js 24, allowing the use of native APIs. The framework emphasizes a convention-over-configuration approach while offering tools for routing, ORM, and authentication.",
        )
        self.assertIn(
            "AdonisJS, the ‘batteries-included Node.js framework’ maintained by Harminder Virk, has released version 7 with end-to-end type safety as its headline feature, alongside reworked starter kits, zero-configuration observability, and a completely rebuilt documentation site.",
            article.body,
        )
        self.assertIn(
            "The sweet spot for TypeScript-first backend work right now",
            article.body,
        )
        self.assertNotIn("About the Author", article.body)
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/jpeg")


if __name__ == "__main__":
    unittest.main()
