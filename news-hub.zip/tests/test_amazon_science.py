from scrapers.amazon_science import AmazonScienceScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <item>
      <title>Navigating uncertainty in Amazon's middle-mile network</title>
      <link>https://www.amazon.science/blog/navigating-uncertainty-in-amazons-middle-mile-network</link>
      <description>Amazon engineers and scientists have created new tools to optimize delivery networks under uncertainty — and keep them adapting without missing a beat.</description>
      <content:encoded>Before the "last mile" delivery driver sets off for your home, your Amazon item has moved through the middle-mile network of fulfillment centers and sort centers.</content:encoded>
      <pubDate>Wed, 06 May 2026 13:37:38 GMT</pubDate>
      <guid>https://www.amazon.science/blog/navigating-uncertainty-in-amazons-middle-mile-network</guid>
    </item>
  </channel>
</rss>
"""

SAMPLE_ARTICLE_HTML = """<html>
  <head>
    <meta property="og:title" content="Wrong page title" />
    <meta property="og:description" content="Wrong page description" />
    <meta property="og:image" content="https://example.com/amazon-science.jpg" />
    <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": "Wrong JSON-LD headline",
        "datePublished": "2000-01-01T00:00:00Z"
      }
    </script>
  </head>
  <body>
    <article>Wrong body from page</article>
  </body>
</html>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class AmazonScienceScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_fields_and_page_image_only(self) -> None:
        scraper = AmazonScienceScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://www.amazon.science/blog/navigating-uncertainty-in-amazons-middle-mile-network":
                return _FakeResponse(text=SAMPLE_ARTICLE_HTML)
            if url == "https://example.com/amazon-science.jpg":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/jpeg"},
                )
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.url,
            "https://www.amazon.science/blog/navigating-uncertainty-in-amazons-middle-mile-network",
        )
        self.assertEqual(
            article.title,
            "Navigating uncertainty in Amazon's middle-mile network",
        )
        self.assertIsNone(article.author)
        self.assertEqual(article.tags, [])
        self.assertEqual(
            article.description,
            "Amazon engineers and scientists have created new tools to optimize delivery networks under uncertainty — and keep them adapting without missing a beat.",
        )
        self.assertEqual(
            article.body,
            'Before the "last mile" delivery driver sets off for your home, your Amazon item has moved through the middle-mile network of fulfillment centers and sort centers.',
        )
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 6, 13, 37, 38, tzinfo=timezone.utc),
        )
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/jpeg")


if __name__ == "__main__":
    unittest.main()
