from scrapers.google_research import GoogleResearchScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:media="http://search.yahoo.com/mrss/">
  <channel>
    <item>
      <title>Catalyzing scientific impact through global partnerships and open resources</title>
      <link>https://research.google/blog/catalyzing-scientific-impact-through-global-partnerships-and-open-resources/</link>
      <description>Data Mining &amp; Modeling</description>
      <pubDate>Fri, 01 May 2026 16:37:00 +0000</pubDate>
      <guid>https://research.google/blog/catalyzing-scientific-impact-through-global-partnerships-and-open-resources/</guid>
      <category>Data Mining &amp; Modeling</category>
      <category>General Science</category>
      <category>Health &amp; Bioscience</category>
      <category>Open Source Models &amp; Datasets</category>
      <media:thumbnail url="https://storage.googleapis.com/gweb-research2023-media/original_images/Open_science_1.png"/>
      <media:content medium="image" url="https://storage.googleapis.com/gweb-research2023-media/original_images/Open_science_1.png"/>
    </item>
  </channel>
</rss>
"""

SAMPLE_ARTICLE_HTML = """<html>
  <head>
    <meta property="og:description" content="Wrong description from page metadata" />
  </head>
  <body>
    <div class="blog-summary__summary">Our approach to open science is built on principles of responsible, inclusive, and rigorous research, empowering a global community to drive high-impact discoveries across disciplines and accelerate progress for all.</div>
    <div class="blog-detail-wrapper">
      <p>A scientific breakthrough reaches its full potential only when it empowers others to replicate and expand upon findings.</p>
      <p>We believe that creating these resources responsibly and maintaining them through partnerships with the global scientific community embodies the spirit of collaboration.</p>
    </div>
  </body>
</html>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class GoogleResearchScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_metadata_and_page_content(self) -> None:
        scraper = GoogleResearchScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://research.google/blog/catalyzing-scientific-impact-through-global-partnerships-and-open-resources/":
                return _FakeResponse(text=SAMPLE_ARTICLE_HTML)
            if url == "https://storage.googleapis.com/gweb-research2023-media/original_images/Open_science_1.png":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/png"},
                )
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.url,
            "https://research.google/blog/catalyzing-scientific-impact-through-global-partnerships-and-open-resources/",
        )
        self.assertEqual(
            article.title,
            "Catalyzing scientific impact through global partnerships and open resources",
        )
        self.assertEqual(
            article.tags,
            [
                "Data Mining & Modeling",
                "General Science",
                "Health & Bioscience",
                "Open Source Models & Datasets",
            ],
        )
        self.assertEqual(
            article.description,
            "Our approach to open science is built on principles of responsible, inclusive, and rigorous research, empowering a global community to drive high-impact discoveries across disciplines and accelerate progress for all.",
        )
        self.assertIn(
            "A scientific breakthrough reaches its full potential only when it empowers others to replicate and expand upon findings.",
            article.body,
        )
        self.assertIn(
            "We believe that creating these resources responsibly and maintaining them through partnerships with the global scientific community embodies the spirit of collaboration.",
            article.body,
        )
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/png")
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 1, 16, 37, 0, tzinfo=timezone.utc),
        )


if __name__ == "__main__":
    unittest.main()
