from scrapers.cio_elets import CioEletsScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
 xmlns:content="http://purl.org/rss/1.0/modules/content/"
 xmlns:dc="http://purl.org/dc/elements/1.1/"
 xmlns:media="http://search.yahoo.com/mrss/">
  <channel>
    <item>
      <title>How Enterprises Must Prepare for AI Co-Workers in the Age of Agentic AI</title>
      <link>https://cio.eletsonline.com/news/how-enterprises-must-prepare-for-ai-co-workers-in-the-age-of-agentic-ai/76095/</link>
      <dc:creator><![CDATA[cioNetworks]]></dc:creator>
      <pubDate>Tue, 12 May 2026 13:15:15 +0000</pubDate>
      <category><![CDATA[News]]></category>
      <category><![CDATA[Agentic AI]]></category>
      <category><![CDATA[AI Co-Workers]]></category>
      <category><![CDATA[Enterprises]]></category>
      <guid isPermaLink="false">https://cio.eletsonline.com/?p=76095</guid>
      <description><![CDATA[<p>As agentic AI becomes more capable of executing tasks autonomously, enterprises are being urged to prepare for a future where [&#8230;]</p>
<p>The post <a href="https://cio.eletsonline.com/news/how-enterprises-must-prepare-for-ai-co-workers-in-the-age-of-agentic-ai/76095/">How Enterprises Must Prepare for AI Co-Workers in the Age of Agentic AI</a> appeared first on <a href="https://cio.eletsonline.com">Elets CIO</a>.</p>]]></description>
      <content:encoded><![CDATA[<p><span style="font-weight: 400;">As agentic AI becomes more capable of executing tasks autonomously, enterprises are being urged to prepare for a future where AI systems function as digital co-workers rather than simple productivity tools.</span></p>
<p><span style="font-weight: 400;">Unlike traditional AI assistants that support individual tasks, AI co-workers can understand goals, make decisions, and carry out end-to-end workflows with limited human intervention.</span></p>
<p>The post <a href="https://cio.eletsonline.com/news/how-enterprises-must-prepare-for-ai-co-workers-in-the-age-of-agentic-ai/76095/">How Enterprises Must Prepare for AI Co-Workers in the Age of Agentic AI</a> appeared first on <a href="https://cio.eletsonline.com">Elets CIO</a>.</p>]]></content:encoded>
      <media:content url="https://cio.eletsonline.com/wp-content/uploads/2026/05/Agentic-AI.jpg" medium="image" />
    </item>
  </channel>
</rss>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class CioEletsScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_content_without_article_page_fetch(self) -> None:
        scraper = CioEletsScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://cio.eletsonline.com/wp-content/uploads/2026/05/Agentic-AI.jpg":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/jpeg"},
                )
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.url,
            "https://cio.eletsonline.com/news/how-enterprises-must-prepare-for-ai-co-workers-in-the-age-of-agentic-ai/76095/",
        )
        self.assertEqual(
            article.title,
            "How Enterprises Must Prepare for AI Co-Workers in the Age of Agentic AI",
        )
        self.assertEqual(article.author, "cioNetworks")
        self.assertEqual(
            article.tags, ["News", "Agentic AI", "AI Co-Workers", "Enterprises"])
        self.assertEqual(
            article.description,
            "As agentic AI becomes more capable of executing tasks autonomously, enterprises are being urged to prepare for a future where […]",
        )
        self.assertIn(
            "As agentic AI becomes more capable of executing tasks autonomously, enterprises are being urged to prepare for a future where AI systems function as digital co-workers rather than simple productivity tools.",
            article.body,
        )
        self.assertIn(
            "Unlike traditional AI assistants that support individual tasks, AI co-workers can understand goals, make decisions, and carry out end-to-end workflows with limited human intervention.",
            article.body,
        )
        self.assertNotIn("The post", article.body)
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/jpeg")
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 12, 13, 15, 15, tzinfo=timezone.utc),
        )


if __name__ == "__main__":
    unittest.main()
