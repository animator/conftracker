from src.models import Article


def test_non_arxiv_articles_omit_pdf_fields() -> None:
    article = Article(
        url="https://example.com/post",
        url_key="example-post",
        title="Example",
        source_name="techcrunch",
    )

    payload = article.to_dict()

    assert "pdf" not in payload
    assert "pdf_mimetype" not in payload
    assert "pdf_url" not in payload


def test_arxiv_articles_include_pdf_fields() -> None:
    article = Article(
        url="https://arxiv.org/abs/1234.5678",
        url_key="1234.5678",
        title="Example paper",
        source_name="arxiv",
        pdf_url="https://arxiv.org/pdf/1234.5678",
    )

    payload = article.to_dict()

    assert payload["pdf"] is None
    assert payload["pdf_mimetype"] is None
    assert payload["pdf_url"] == "https://arxiv.org/pdf/1234.5678"
