from scrapers.marktechpost import MarkTechPostScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
 xmlns:content="http://purl.org/rss/1.0/modules/content/"
 xmlns:dc="http://purl.org/dc/elements/1.1/">
  <channel>
    <item>
      <title>Build a Hybrid-Memory Autonomous Agent with Modular Architecture and Tool Dispatch Using OpenAI</title>
      <link>https://www.marktechpost.com/2026/05/12/build-a-hybrid-memory-autonomous-agent-with-modular-architecture-and-tool-dispatch-using-openai/</link>
      <dc:creator><![CDATA[Sana Hassan]]></dc:creator>
      <pubDate>Tue, 12 May 2026 21:55:57 +0000</pubDate>
      <category><![CDATA[Agentic AI]]></category>
      <category><![CDATA[Editors Pick]]></category>
      <category><![CDATA[Software Engineering]]></category>
      <category><![CDATA[Staff]]></category>
      <category><![CDATA[Tutorials]]></category>
      <description><![CDATA[
        <p>In this tutorial, we begin by exploring the architecture behind a hybrid-memory autonomous agent.</p>
        <p>The post <a href="https://www.marktechpost.com/2026/05/12/build-a-hybrid-memory-autonomous-agent-with-modular-architecture-and-tool-dispatch-using-openai/">Build a Hybrid-Memory Autonomous Agent with Modular Architecture and Tool Dispatch Using OpenAI</a> appeared first on <a href="https://www.marktechpost.com">MarkTechPost</a>.</p>
      ]]></description>
      <content:encoded><![CDATA[
        <p>In this tutorial, we begin by exploring the architecture behind a hybrid-memory autonomous agent.</p>
        <div class="dm-code-snippet dark dm-normal-version default no-background-mobile">
          <div class="control-language">
            <a id="dm-copy-raw-code"><span class="dm-copy-text">Copy Code</span></a>
          </div>
          <pre><code>!pip install openai numpy rank_bm25 --quiet\nprint("OpenAI client ready.")</code></pre>
        </div>
        <p>We define the three core abstract base classes, MemoryBackend, LLMProvider, and Tool.</p>
        <hr />
        <p></p>
        <p>Check out the <strong><a href="https://github.com/Marktechpost/AI-Agents-Projects-Tutorials/blob/main/AI%20Agents%20Codes/hybrid_memory_autonomous_agent_Marktechpost.ipynb">Full Codes with Notebook here</a>.</strong> Also, feel free to follow us on Twitter.</p>
        <p>Need to partner with us for promoting your GitHub Repo OR Hugging Face Page OR Product Release OR Webinar etc.? <strong><a href="https://forms.gle/MTNLpmJtsFA3VRVd9">Connect with us</a></strong></p>
        <p>The post <a href="https://www.marktechpost.com/2026/05/12/build-a-hybrid-memory-autonomous-agent-with-modular-architecture-and-tool-dispatch-using-openai/">Build a Hybrid-Memory Autonomous Agent with Modular Architecture and Tool Dispatch Using OpenAI</a> appeared first on <a href="https://www.marktechpost.com">MarkTechPost</a>.</p>
      ]]></content:encoded>
    </item>
  </channel>
</rss>
"""

SAMPLE_ARTICLE_HTML = """<html>
  <head>
    <meta property="og:image" content="https://cdn.example.com/marktechpost-og.jpg" />
  </head>
  <body>
    <article>Page body should not be used.</article>
  </body>
</html>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class MarkTechPostScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_fields_and_page_og_image(self) -> None:
        scraper = MarkTechPostScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://www.marktechpost.com/2026/05/12/build-a-hybrid-memory-autonomous-agent-with-modular-architecture-and-tool-dispatch-using-openai/":
                return _FakeResponse(text=SAMPLE_ARTICLE_HTML)
            if url == "https://cdn.example.com/marktechpost-og.jpg":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/jpeg"},
                )
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.title,
            "Build a Hybrid-Memory Autonomous Agent with Modular Architecture and Tool Dispatch Using OpenAI",
        )
        self.assertEqual(article.author, "Sana Hassan")
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 12, 21, 55, 57, tzinfo=timezone.utc),
        )
        self.assertEqual(
            article.tags,
            ["Agentic AI", "Editors Pick",
                "Software Engineering", "Staff", "Tutorials"],
        )
        self.assertEqual(
            article.description,
            "In this tutorial, we begin by exploring the architecture behind a hybrid-memory autonomous agent.",
        )
        self.assertIn(
            "In this tutorial, we begin by exploring the architecture behind a hybrid-memory autonomous agent.",
            article.body,
        )
        self.assertIn(
            "!pip install openai numpy rank_bm25 --quiet", article.body)
        self.assertIn(
            "We define the three core abstract base classes, MemoryBackend, LLMProvider, and Tool.",
            article.body,
        )
        self.assertNotIn("Copy Code", article.body)
        self.assertNotIn("Check out the Full Codes", article.body)
        self.assertNotIn("Need to partner with us", article.body)
        self.assertNotIn("The post", article.body)
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/jpeg")


if __name__ == "__main__":
    unittest.main()
