from scrapers.venturebeat import VentureBeatScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <item>
      <title><![CDATA[Perceptron Mk1 shocks with highly performant video analysis AI model 80-90% cheaper than Anthropic, OpenAI &amp; Google]]></title>
      <link>https://venturebeat.com/technology/perceptron-mk1-shocks-with-highly-performant-video-analysis-ai-model-80-90-cheaper-than-anthropic-openai-and-google</link>
      <guid isPermaLink="false">1WGzLcJhg1qGXiRGzwynpv</guid>
      <pubDate>Tue, 12 May 2026 18:45:17 GMT</pubDate>
      <description><![CDATA[
        <p>AI that can see and understand what's happening in a video — especially a live feed — is understandably an attractive product to lots of enterprises and organizations.</p>
        <p>While there are some AI models that offer this type of functionality today, it's far from a mainstream capability.</p>
        <h2><b>Performance across spatial and video benchmarks</b></h2>
        <p>The model's performance is backed by a suite of industry-standard benchmarks focused on grounded understanding.</p>
      ]]></description>
      <author>carl.franzen@venturebeat.com (Carl Franzen)</author>
      <category>Technology</category>
      <enclosure url="https://images.ctfassets.net/jdtwqhzvc2n1/792xpzV56beWnPgMn8j8Ku/2e0da2eadb098389cada35ebac209693/ChatGPT_Image_May_12__2026__02_26_29_PM.png?w=300&amp;q=30" length="0" type="image/png"/>
    </item>
  </channel>
</rss>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class VentureBeatScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_fields_without_article_page_fetch(self) -> None:
        scraper = VentureBeatScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://images.ctfassets.net/jdtwqhzvc2n1/792xpzV56beWnPgMn8j8Ku/2e0da2eadb098389cada35ebac209693/ChatGPT_Image_May_12__2026__02_26_29_PM.png?w=300&q=30":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/png"},
                )
            if url == "https://venturebeat.com/technology/perceptron-mk1-shocks-with-highly-performant-video-analysis-ai-model-80-90-cheaper-than-anthropic-openai-and-google":
                raise AssertionError("Article page should not be fetched")
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.title,
            "Perceptron Mk1 shocks with highly performant video analysis AI model 80-90% cheaper than Anthropic, OpenAI & Google",
        )
        self.assertEqual(article.author, "Carl Franzen")
        self.assertEqual(article.tags, ["Technology"])
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 12, 18, 45, 17, tzinfo=timezone.utc),
        )
        self.assertIsNone(article.description)
        self.assertIn(
            "AI that can see and understand what's happening in a video — especially a live feed — is understandably an attractive product to lots of enterprises and organizations.",
            article.body,
        )
        self.assertIn(
            "Performance across spatial and video benchmarks",
            article.body,
        )
        self.assertIn(
            "The model's performance is backed by a suite of industry-standard benchmarks focused on grounded understanding.",
            article.body,
        )
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/png")


if __name__ == "__main__":
    unittest.main()
