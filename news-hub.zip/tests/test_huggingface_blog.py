from scrapers.huggingface_blog import HuggingfaceBlogScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <item>
      <title>Building Blocks for Foundation Model Training and Inference on AWS</title>
      <pubDate>Mon, 11 May 2026 23:18:26 GMT</pubDate>
      <link>https://huggingface.co/blog/amazon/foundation-model-building-blocks</link>
      <guid isPermaLink="false">https://huggingface.co/blog/amazon/foundation-model-building-blocks</guid>
    </item>
  </channel>
</rss>
"""

SAMPLE_ARTICLE_HTML = """<html>
  <head>
    <meta property="og:image" content="https://huggingface.co/datasets/huggingface/documentation-images/resolve/main/blog/hf-blog.png" />
  </head>
  <body>
    <div class="blog-content">
      <div class="mb-4">Back to Articles</div>
      <h1>Building Blocks for Foundation Model Training and Inference on AWS</h1>
      <div>Enterprise Article Published May 11, 2026</div>
      <div class="not-prose">Keita Watanabe Pavel Belevich Aman Shanbhag</div>
      <div class="absolute">
        <div class="sticky">
          <div class="h-7">
            <div class="toc">
              <nav>The AWS Building Blocks Infrastructure: Compute, Network, and Storage Resource Orchestration</nav>
            </div>
          </div>
        </div>
      </div>
      [-1]]]
      For a long time, "scaling" in foundation models mostly meant one thing: spend more compute on pre-training and capabilities rise. That intuition was supported by empirical work such as
      <a>Kaplan et al. (2020)</a>, which reported predictable power-law trends in loss as you scale
      <strong>model parameters</strong>,
      <strong>dataset size</strong>, and
      <strong>training compute</strong>. In practice, these trends justified sustained investment in large-scale accelerator capacity and the surrounding distributed infrastructure needed to keep it efficiently utilized.
      <p></p>
      <blockquote>Figure: Adapted from "AI's Three Scaling Laws, Explained" (NVIDIA Blog).</blockquote>
      <h2>The AWS Building Blocks</h2>
      <p>Teams need to think about compute, storage, and orchestration together to build reliable large-scale systems.</p>
      <ul>
        <li>Infrastructure: Compute, Network, and Storage</li>
        <li>Resource Orchestration: Slurm and Kubernetes</li>
      </ul>
    </div>
  </body>
</html>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class HuggingfaceBlogScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_title_date_and_cleaned_blog_content(self) -> None:
        scraper = HuggingfaceBlogScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://huggingface.co/blog/amazon/foundation-model-building-blocks":
                return _FakeResponse(text=SAMPLE_ARTICLE_HTML)
            if url == "https://huggingface.co/datasets/huggingface/documentation-images/resolve/main/blog/hf-blog.png":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/png"},
                )
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.url,
            "https://huggingface.co/blog/amazon/foundation-model-building-blocks",
        )
        self.assertEqual(
            article.title,
            "Building Blocks for Foundation Model Training and Inference on AWS",
        )
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 11, 23, 18, 26, tzinfo=timezone.utc),
        )
        self.assertIsNone(article.description)
        self.assertEqual(article.author, None)
        self.assertTrue(
            article.body.startswith(
                'For a long time, "scaling" in foundation models mostly meant one thing: spend more compute on pre-training and capabilities rise. That intuition was supported by empirical work such as Kaplan et al. (2020), which reported predictable power-law trends in loss as you scale model parameters, dataset size, and training compute.'
            ),
            article.body,
        )
        self.assertIn(
            "The AWS Building Blocks",
            article.body,
        )
        self.assertIn(
            "Infrastructure: Compute, Network, and Storage",
            article.body,
        )
        self.assertNotIn("Back to Articles", article.body)
        self.assertNotIn("Enterprise Article Published", article.body)
        self.assertNotIn("Keita Watanabe", article.body)
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/png")


if __name__ == "__main__":
    unittest.main()
