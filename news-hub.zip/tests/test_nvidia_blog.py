from scrapers.nvidia_blog import NvidiaBlogScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
 xmlns:content="http://purl.org/rss/1.0/modules/content/"
 xmlns:dc="http://purl.org/dc/elements/1.1/"
 xmlns:media="http://search.yahoo.com/mrss/">
  <channel>
    <item>
      <title>NVIDIA and SAP Bring Trust to Specialized Agents</title>
      <link>https://blogs.nvidia.com/blog/sap-specialized-agents/</link>
      <dc:creator><![CDATA[Justin Boitano]]></dc:creator>
      <pubDate>Tue, 12 May 2026 12:30:56 +0000</pubDate>
      <category><![CDATA[AI]]></category>
      <category><![CDATA[Corporate]]></category>
      <category><![CDATA[Agentic AI]]></category>
      <category><![CDATA[Artificial Intelligence]]></category>
      <category><![CDATA[Open Source]]></category>
      <description><![CDATA[Announced today at SAP Sapphire — where NVIDIA founder and CEO Jensen Huang joined SAP CEO Christian Klein’s keynote by video — SAP and NVIDIA’s expanded collaboration helps enterprises run specialized agents with security and governance controls. ]]></description>
      <content:encoded><![CDATA[
        <div id="bsf_rt_marker"></div>
        <p><span style="font-weight: 400;">From finance and procurement to supply chain and manufacturing, specialized AI agents are moving into the enterprise systems where business decisions are made, data is accessed and workflows run at scale.</span></p>
        <p><span style="font-weight: 400;">Announced today at SAP Sapphire — where NVIDIA founder and CEO Jensen Huang joined SAP CEO Christian Klein’s keynote by video — SAP and NVIDIA’s expanded collaboration helps enterprises run specialized agents with security and governance controls.</span></p>
        <h2><b>Why the Application Layer Matters</b></h2>
        <ul>
          <li>NVIDIA OpenShell asks: Can this agent action safely execute?</li>
          <li>Joule Studio runtime — the enterprise control layer within SAP Business AI Platform — asks: Should this action happen at all?</li>
        </ul>
        <p><i>Learn more about </i><a target="_blank" href="https://build.nvidia.com/openshell"><i>NVIDIA OpenShell</i></a><i> and </i><a target="_blank" href="https://www.nvidia.com/en-us/ai/nemoclaw/"><i>NemoClaw</i></a><i>.</i></p>
      ]]></content:encoded>
      <media:content url="https://blogs.nvidia.com/wp-content/uploads/2026/05/logo-lockup-blog-SAP-1920x1080-1.jpg" type="image/jpeg" width="1920" height="1080">
        <media:thumbnail url="https://blogs.nvidia.com/wp-content/uploads/2026/05/logo-lockup-blog-SAP-1920x1080-1-842x450.jpg" width="842" height="450" />
      </media:content>
    </item>
  </channel>
</rss>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class NvidiaBlogScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_fields_without_article_page_fetch(self) -> None:
        scraper = NvidiaBlogScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://blogs.nvidia.com/wp-content/uploads/2026/05/logo-lockup-blog-SAP-1920x1080-1-842x450.jpg":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/jpeg"},
                )
            if url == "https://blogs.nvidia.com/blog/sap-specialized-agents/":
                raise AssertionError("Article page should not be fetched")
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.title, "NVIDIA and SAP Bring Trust to Specialized Agents")
        self.assertEqual(article.author, "Justin Boitano")
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 12, 12, 30, 56, tzinfo=timezone.utc),
        )
        self.assertEqual(
            article.tags,
            ["AI", "Corporate", "Agentic AI",
                "Artificial Intelligence", "Open Source"],
        )
        self.assertEqual(
            article.description,
            "Announced today at SAP Sapphire — where NVIDIA founder and CEO Jensen Huang joined SAP CEO Christian Klein’s keynote by video — SAP and NVIDIA’s expanded collaboration helps enterprises run specialized agents with security and governance controls.",
        )
        self.assertIn(
            "From finance and procurement to supply chain and manufacturing, specialized AI agents are moving into the enterprise systems where business decisions are made, data is accessed and workflows run at scale.",
            article.body,
        )
        self.assertIn("Why the Application Layer Matters", article.body)
        self.assertIn(
            "NVIDIA OpenShell asks: Can this agent action safely execute?", article.body)
        self.assertIn(
            "Learn more about NVIDIA OpenShell and NemoClaw.", article.body)
        self.assertNotIn("bsf_rt_marker", article.body)
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/jpeg")


if __name__ == "__main__":
    unittest.main()
