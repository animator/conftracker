from scrapers.cxodigitalpulse import CxoDigitalPulseScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
 xmlns:content="http://purl.org/rss/1.0/modules/content/"
 xmlns:dc="http://purl.org/dc/elements/1.1/">
  <channel>
    <item>
      <title>Wibe Algo Co-Founder’s Launches ‘SAGA’</title>
      <link>https://www.cxodigitalpulse.com/wibe-algo-co-founders-launches-saga/</link>
      <dc:creator><![CDATA[News]]></dc:creator>
      <pubDate>Tue, 12 May 2026 11:57:49 +0000</pubDate>
      <category><![CDATA[News/Media]]></category>
      <guid isPermaLink="false">https://www.cxodigitalpulse.com/?p=53713</guid>
      <description><![CDATA[<p>India, May , 2026 – On National Technology Day, “SAGA” launches as a first-of-its-kind All-Search Visibility and Intelligence Platform, signalling a new era where technology no longer just enables action but actively shapes what is seen, trusted, and chosen. SAGA provides the intelligence layer required for brands to move from manual optimization to being accurately synthesized by the algorithms [&#8230;]</p>
<p>The post <a href="https://www.cxodigitalpulse.com/wibe-algo-co-founders-launches-saga/">Wibe Algo Co-Founder’s Launches ‘SAGA’</a> appeared first on <a href="https://www.cxodigitalpulse.com">CXO Digitalpulse</a>.</p>]]></description>
      <content:encoded><![CDATA[<p><img fetchpriority="high" decoding="async" class="alignnone size-full wp-image-53714" src="https://www.cxodigitalpulse.com/wp-content/uploads/2026/05/b-105.webp" alt="" width="905" height="393" /></p>
<p><strong><b>India, May , 2026</b></strong> – On <strong><b>National Technology Day,</b></strong> <strong><b>“SAGA”</b></strong> launches as a <strong><b>first-of-its-kind All-Search Visibility</b></strong> and <strong><b>Intelligence Platform</b></strong>, signalling a new era where technology no longer just enables action but actively shapes what is seen, trusted, and chosen.</p>
<p>SAGA provides the intelligence layer required for brands to move from manual optimization to being accurately synthesized by the algorithms that now define the decision journey.</p>
<p>The post <a href="https://www.cxodigitalpulse.com/wibe-algo-co-founders-launches-saga/">Wibe Algo Co-Founder’s Launches ‘SAGA’</a> appeared first on <a href="https://www.cxodigitalpulse.com">CXO Digitalpulse</a>.</p>]]></content:encoded>
    </item>
  </channel>
</rss>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class CxoDigitalPulseScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_content_and_lead_image_without_article_page_fetch(self) -> None:
        scraper = CxoDigitalPulseScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://www.cxodigitalpulse.com/wp-content/uploads/2026/05/b-105.webp":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/webp"},
                )
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.url,
            "https://www.cxodigitalpulse.com/wibe-algo-co-founders-launches-saga/",
        )
        self.assertEqual(
            article.title, "Wibe Algo Co-Founder’s Launches ‘SAGA’")
        self.assertEqual(article.author, "News")
        self.assertEqual(article.tags, ["News/Media"])
        self.assertEqual(
            article.description,
            "India, May, 2026 – On National Technology Day, “SAGA” launches as a first-of-its-kind All-Search Visibility and Intelligence Platform, signalling a new era where technology no longer just enables action but actively shapes what is seen, trusted, and chosen. SAGA provides the intelligence layer required for brands to move from manual optimization to being accurately synthesized by the algorithms […]",
        )
        self.assertIn(
            "India, May, 2026 – On National Technology Day, “SAGA” launches as a first-of-its-kind All-Search Visibility and Intelligence Platform, signalling a new era where technology no longer just enables action but actively shapes what is seen, trusted, and chosen.",
            article.body,
        )
        self.assertIn(
            "SAGA provides the intelligence layer required for brands to move from manual optimization to being accurately synthesized by the algorithms that now define the decision journey.",
            article.body,
        )
        self.assertNotIn("The post", article.body)
        self.assertNotIn("b-105.webp", article.body)
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/webp")
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 12, 11, 57, 49, tzinfo=timezone.utc),
        )


if __name__ == "__main__":
    unittest.main()
