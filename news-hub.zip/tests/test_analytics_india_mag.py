from scrapers.analytics_india_mag import AnalyticsIndiaMagScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import Mock


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
 xmlns:content="http://purl.org/rss/1.0/modules/content/"
 xmlns:dc="http://purl.org/dc/elements/1.1/"
 xmlns:media="http://search.yahoo.com/mrss/">
  <channel>
    <item>
      <title><![CDATA[OpenAI Enters Consulting Arena, and India's IT Stocks are Paying the Price]]></title>
      <link>https://analyticsindiamag.com/it-services/openai-enters-consulting-arena-and-indias-it-stocks-are-paying-the-price</link>
      <guid isPermaLink="true">https://analyticsindiamag.com/it-services/openai-enters-consulting-arena-and-indias-it-stocks-are-paying-the-price</guid>
      <pubDate>Tue, 12 May 2026 13:18:19 GMT</pubDate>
      <dc:creator><![CDATA[Ajay Rag]]></dc:creator>
      <category><![CDATA[IT Services]]></category>
      <description><![CDATA[OpenAI's $4 billion Deployment Company has sent shockwaves through India's technology sector, plunging the Nifty IT index by 3.7%.]]></description>
      <content:encoded><![CDATA[<p>After Indian information technology (IT) stocks took a beating when Anthropic announced an enterprise-focused joint venture.</p><p>TCS, Infosys, and HCLTech all touched their 52-week lows during the session.</p>]]></content:encoded>
      <media:content url="https://example.com/test.webp" medium="image"/>
      <enclosure url="https://example.com/test.webp" type="image/jpeg"/>
    </item>
  </channel>
</rss>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class AnalyticsIndiaMagScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_content_without_rendering_pages(self) -> None:
        scraper = AnalyticsIndiaMagScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://example.com/test.webp":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/webp"},
                )
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]
        scraper.fetch_rendered = Mock(  # type: ignore[assignment]
            side_effect=AssertionError("fetch_rendered should not be called")
        )

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.url,
            "https://analyticsindiamag.com/it-services/openai-enters-consulting-arena-and-indias-it-stocks-are-paying-the-price",
        )
        self.assertEqual(
            article.title,
            "OpenAI Enters Consulting Arena, and India's IT Stocks are Paying the Price",
        )
        self.assertEqual(article.author, "Ajay Rag")
        self.assertEqual(article.tags, ["IT Services"])
        self.assertEqual(
            article.description,
            "OpenAI's $4 billion Deployment Company has sent shockwaves through India's technology sector, plunging the Nifty IT index by 3.7%.",
        )
        self.assertIn(
            "After Indian information technology (IT) stocks took a beating when Anthropic announced an enterprise-focused joint venture.",
            article.body,
        )
        self.assertIn(
            "TCS, Infosys, and HCLTech all touched their 52-week lows during the session.",
            article.body,
        )
        self.assertNotIn("<p>", article.body)
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/webp")
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 12, 13, 18, 19, tzinfo=timezone.utc),
        )
        scraper.fetch_rendered.assert_not_called()

    def test_parse_article_page_is_not_supported(self) -> None:
        scraper = AnalyticsIndiaMagScraper()

        with self.assertRaises(NotImplementedError):
            scraper.parse_article_page("https://analyticsindiamag.com/example")


if __name__ == "__main__":
    unittest.main()
