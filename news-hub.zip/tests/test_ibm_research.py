from scrapers.ibm_research import IbmResearchScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <item>
      <title><![CDATA[MIT and IBM renew their research collaboration]]></title>
      <link>https://research.ibm.com/blog/mit-ibm-computing-david-cox?utm_medium=rss&amp;utm_source=rss</link>
      <guid isPermaLink="false">/blog/mit-ibm-computing-david-cox</guid>
      <pubDate>Mon, 11 May 2026 15:00:00 GMT</pubDate>
      <description><![CDATA[We spoke with IBMâ€™s David Cox about the lab's evolution and what it takes for an industry-academia collaboration to succeed.]]></description>
      <category>Accelerated Discovery</category>
      <category>AI</category>
      <category>Natural Language Processing</category>
      <category>Q &amp; A</category>
      <category>Quantum</category>
      <category>Quantum Algorithms</category>
    </item>
  </channel>
</rss>
"""

SAMPLE_ARTICLE_HTML = """<html>
  <head>
    <script type="application/ld+json" data-next-head="">{"@type":"Article","author":[{"@type":"Person","name":"Kim Martineau","url":"https://research.ibm.com/blog?author=kim-martineau"}],"headline":"IBM charts a new research path with MIT","datePublished":"2026-05-11T15:00:00.000Z","description":"We spoke with IBM’s David Cox about the new MIT-IBM Computing Research Lab, what it takes for an industry-academia collaboration to succeed, and why this moment feels charged with possibility.","image":{"@type":"ImageObject","url":"https://research-website-prod-cms-uploads.s3.us.cloud-object-storage.appdomain.cloud/mit_dome_00_1c547b0744.png","width":"900","height":"600"},"@context":"https://schema.org"}</script>
  </head>
  <body>
    <div id="main-content">
      <div class="eWFhm">
        <div class="i756f GwbB5">
          <h1>IBM charts a new research path with MIT</h1>
          <div>11 May 2026 Q &amp; A 7 minute read</div>
          <p>We spoke with IBM’s David Cox about the new MIT-IBM Computing Research Lab, what it takes for an industry-academia collaboration to succeed, and why this moment feels charged with possibility.</p>
          <p>IBM recently signed new collaborative research agreements with ETH Zurich and the University of Illinois, in addition to MIT.</p>
          <h2>The lab is expanding into quantum computing. Why now?</h2>
          <p>The aperture is much wider. Quantum is on an arc to become very powerful in the next few years.</p>
        </div>
      </div>
      <section class="LVjGx">
        <article>Related posts should not be included.</article>
      </section>
    </div>
  </body>
</html>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class IbmResearchScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_tags_date_and_page_content(self) -> None:
        scraper = IbmResearchScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://research.ibm.com/blog/mit-ibm-computing-david-cox?utm_medium=rss&utm_source=rss":
                return _FakeResponse(text=SAMPLE_ARTICLE_HTML)
            if url == "https://research-website-prod-cms-uploads.s3.us.cloud-object-storage.appdomain.cloud/mit_dome_00_1c547b0744.png":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/png"},
                )
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.url,
            "https://research.ibm.com/blog/mit-ibm-computing-david-cox?utm_medium=rss&utm_source=rss",
        )
        self.assertEqual(
            article.title, "MIT and IBM renew their research collaboration")
        self.assertEqual(article.author, "Kim Martineau")
        self.assertEqual(
            article.tags,
            [
                "Accelerated Discovery",
                "AI",
                "Natural Language Processing",
                "Q & A",
                "Quantum",
                "Quantum Algorithms",
            ],
        )
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 11, 15, 0, 0, tzinfo=timezone.utc),
        )
        self.assertEqual(
            article.description,
            "We spoke with IBM’s David Cox about the new MIT-IBM Computing Research Lab, what it takes for an industry-academia collaboration to succeed, and why this moment feels charged with possibility.",
        )
        self.assertIn(
            "IBM recently signed new collaborative research agreements with ETH Zurich and the University of Illinois, in addition to MIT.",
            article.body,
        )
        self.assertIn(
            "The lab is expanding into quantum computing. Why now?",
            article.body,
        )
        self.assertIn(
            "The aperture is much wider. Quantum is on an arc to become very powerful in the next few years.",
            article.body,
        )
        self.assertNotIn("Related posts", article.body)
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/png")


if __name__ == "__main__":
    unittest.main()
