from scrapers.opensourceforu import OpenSourceForUScraper
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


SAMPLE_FEED = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"
 xmlns:content="http://purl.org/rss/1.0/modules/content/"
 xmlns:dc="http://purl.org/dc/elements/1.1/">
  <channel>
    <item>
      <title>Google Uncovers First AI-Assisted Zero-Day Exploit</title>
      <link>https://www.opensourceforu.com/2026/05/google-uncovers-first-ai-assisted-zero-day-exploit/</link>
      <dc:creator><![CDATA[Apurba Sen]]></dc:creator>
      <pubDate>Tue, 12 May 2026 08:06:06 +0000</pubDate>
      <category><![CDATA[News]]></category>
      <description><![CDATA[
        <div>
          <a href="https://www.opensourceforu.com/2026/05/google-uncovers-first-ai-assisted-zero-day-exploit/"><img title="Google" src="https://www.opensourceforu.com/wp-content/uploads/2025/10/Googles-Open-Source-MCP-Server-Lets-AI-Analyse-Ads-Data-Through-Natural-Language-350x233.jpg" alt="AI-Built Zero-Day Exploit Targets Open Source Admin Tool Ahead Of Planned Mass Cyberattack" width="675" height="450" /></a>
        </div>
        <p>Google’s GTIG has revealed the first known AI-assisted zero-day exploit targeting an open-source administration platform, highlighting the rapid escalation of AI-powered cyberwarfare and supply-chain threats. Google has warned that cyber criminals and state-backed threat actors are rapidly operationalising generative AI to develop exploits, automate malware campaigns, and scale cyberattacks targeting open-source infrastructure and AI ecosystems. […]</p>
        <p>The post <a rel="nofollow" href="https://www.opensourceforu.com/2026/05/google-uncovers-first-ai-assisted-zero-day-exploit/">Google Uncovers First AI-Assisted Zero-Day Exploit</a> appeared first on <a rel="nofollow" href="https://www.opensourceforu.com">Open Source For You</a>.</p>
      ]]></description>
      <content:encoded><![CDATA[
        <div>
          <a href="https://www.opensourceforu.com/2026/05/google-uncovers-first-ai-assisted-zero-day-exploit/"><img title="Google" src="https://www.opensourceforu.com/wp-content/uploads/2025/10/Googles-Open-Source-MCP-Server-Lets-AI-Analyse-Ads-Data-Through-Natural-Language-350x233.jpg" alt="AI-Built Zero-Day Exploit Targets Open Source Admin Tool Ahead Of Planned Mass Cyberattack" width="675" height="450" /></a>
        </div>
        <p><em>Google’s GTIG has revealed the first known AI-assisted zero-day exploit targeting an open-source administration platform, highlighting the rapid escalation of AI-powered cyberwarfare and supply-chain threats.</em></p>
        <p>Google has warned that cyber criminals and state-backed threat actors are rapidly operationalising generative AI to develop exploits, automate malware campaigns, and scale cyberattacks targeting open-source infrastructure and AI ecosystems.</p>
        <p>In a new report from Google Threat Intelligence Group (GTIG), researchers disclosed the first identified real-world zero-day exploit developed with AI assistance.</p>
        <p>GTIG also highlighted PROMPTSPY, an Android backdoor capable of autonomous AI-agent behaviour through Gemini API integration.</p>
        <p>The post <a rel="nofollow" href="https://www.opensourceforu.com/2026/05/google-uncovers-first-ai-assisted-zero-day-exploit/">Google Uncovers First AI-Assisted Zero-Day Exploit</a> appeared first on <a rel="nofollow" href="https://www.opensourceforu.com">Open Source For You</a>.</p>
      ]]></content:encoded>
    </item>
  </channel>
</rss>
"""


class _FakeResponse:
    def __init__(self, *, text: str = "", content: bytes = b"", headers: dict[str, str] | None = None):
        self.text = text
        self.content = content
        self.headers = headers or {}


class OpenSourceForUScraperTests(unittest.TestCase):
    def test_scrape_uses_feed_fields_without_article_page_fetch(self) -> None:
        scraper = OpenSourceForUScraper()

        def fake_fetch(url: str, **_: object) -> _FakeResponse:
            if url == scraper.FEED_URL:
                return _FakeResponse(text=SAMPLE_FEED)
            if url == "https://www.opensourceforu.com/wp-content/uploads/2025/10/Googles-Open-Source-MCP-Server-Lets-AI-Analyse-Ads-Data-Through-Natural-Language-350x233.jpg":
                return _FakeResponse(
                    content=b"image-bytes",
                    headers={"Content-Type": "image/jpeg"},
                )
            if url == "https://www.opensourceforu.com/2026/05/google-uncovers-first-ai-assisted-zero-day-exploit/":
                raise AssertionError("Article page should not be fetched")
            raise AssertionError(f"Unexpected fetch URL: {url}")

        scraper.fetch = fake_fetch  # type: ignore[assignment]

        articles = list(scraper.scrape(existing_keys=set()))

        self.assertEqual(len(articles), 1)
        article = articles[0]
        self.assertEqual(
            article.title, "Google Uncovers First AI-Assisted Zero-Day Exploit")
        self.assertEqual(article.author, "Apurba Sen")
        self.assertEqual(article.tags, ["News"])
        self.assertEqual(
            article.published_date,
            datetime(2026, 5, 12, 8, 6, 6, tzinfo=timezone.utc),
        )
        self.assertEqual(
            article.description,
            "Google’s GTIG has revealed the first known AI-assisted zero-day exploit targeting an open-source administration platform, highlighting the rapid escalation of AI-powered cyberwarfare and supply-chain threats. Google has warned that cyber criminals and state-backed threat actors are rapidly operationalising generative AI to develop exploits, automate malware campaigns, and scale cyberattacks targeting open-source infrastructure and AI ecosystems. […]",
        )
        self.assertIn(
            "Google’s GTIG has revealed the first known AI-assisted zero-day exploit targeting an open-source administration platform, highlighting the rapid escalation of AI-powered cyberwarfare and supply-chain threats.",
            article.body,
        )
        self.assertIn(
            "In a new report from Google Threat Intelligence Group (GTIG), researchers disclosed the first identified real-world zero-day exploit developed with AI assistance.",
            article.body,
        )
        self.assertIn(
            "GTIG also highlighted PROMPTSPY, an Android backdoor capable of autonomous AI-agent behaviour through Gemini API integration.",
            article.body,
        )
        self.assertNotIn("The post", article.body)
        self.assertEqual(article.og_image, b"image-bytes")
        self.assertEqual(article.og_image_mimetype, "image/jpeg")


if __name__ == "__main__":
    unittest.main()
