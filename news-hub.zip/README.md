# News Hub — Daily News Scraper

A cron-based web scraper that collects daily AI/tech news articles from curated sources and stores them in MongoDB. The scraper runs on a configurable schedule, deduplicates articles, and provides a clean data layer for downstream consumption (API, dashboard, newsletter, etc.).

## Sources

| Source                | Collection Name     | Method                |
| --------------------- | ------------------- | --------------------- |
| analyticsindiamag.com | `analyticsindiamag` | Sitemap / Playwright  |
| arxiv.org             | `arxiv`             | Atom/RSS feed         |
| blog.google           | `google_blog`       | RSS feed              |
| blogs.nvidia.com      | `nvidia_blog`       | RSS feed              |
| infoq.com             | `infoq`             | RSS feed              |
| mashable.com          | `mashable`          | RSS feed              |
| venturebeat.com       | `venturebeat`       | RSS feed / Playwright |
| techcrunch.com        | `techcrunch`        | RSS feed              |
| theverge.com          | `theverge`          | Atom feed             |
| github.com            | `projects`          | HTML Parsing          |
| huggingface.co        | `models`            | HTML Parsing          |
| research.google       | `google_research`   | RSS feed              |
| research.ibm.com      | `ibm_research`      | RSS feed              |
| amazon.science        | `amazon_science`    | RSS feed              |
| ai.stanford.edu/blog  | `stanford_ai`       | RSS feed              |
| blog.ml.cmu.edu       | `cmu_ml`            | RSS feed              |
| huggingface.co/blog   | `huggingface_blog`  | RSS feed              |
| marktechpost.com      | `marktechpost`      | RSS feed              |
| opensourceforu.com    | `opensourceforu`    | RSS feed              |
| cxodigitalpulse.com   | `cxodigitalpulse`   | RSS feed              |
| cio.eletsonline.com   | `cio_elets`         | RSS feed              |

## Project Structure

```
src/
├── main.py              # CLI entry point (Click commands)
├── config.py            # Environment-based configuration
├── db.py                # MongoDB connection & index helpers
├── models.py            # Article and ScrapeRun dataclasses
├── scheduler.py         # APScheduler cron wrapper
├── scrape_runner.py     # Orchestrates scrape cycles
├── logger.py            # Structured JSON logging (structlog)
└── scrapers/
    ├── base.py          # Abstract base scraper (HTTP, retry, rate-limit, parsing)
    ├── registry.py      # Central list of all scraper classes
    ├── amazon_science.py
    ├── analytics_india_mag.py
    ├── arxiv.py
    ├── cio_elets.py
    ├── cmu_ml.py
    ├── cxodigitalpulse.py
    ├── github.py
    ├── google_blog.py
    ├── google_research.py
    ├── huggingface.py
    ├── huggingface_blog.py
    ├── ibm_research.py
    ├── infoq.py
    ├── marktechpost.py
    ├── mashable.py
    ├── nvidia_blog.py
    ├── opensourceforu.py
    ├── stanford_ai.py
    ├── techcrunch.py
    ├── theverge.py
    └── venturebeat.py
```

## Setup

### Prerequisites

- Python 3.10+
- MongoDB running locally or accessible via URI

### MongoDB Setup (macOS)

```bash
# Install MongoDB via Homebrew
brew tap mongodb/brew
brew install mongodb-community

# Start MongoDB
brew services start mongodb-community

# Verify it's running
mongosh --eval "db.runCommand({ping:1})" --quiet
# Expected output: { ok: 1 }
```

> **Troubleshooting:** If MongoDB fails to start after a major version upgrade (e.g., 7.x → 8.x) with a `featureCompatibilityVersion` error, back up and reset the data directory:
>
> ```bash
> brew services stop mongodb-community
> mv /opt/homebrew/var/mongodb /opt/homebrew/var/mongodb.bak
> mkdir -p /opt/homebrew/var/mongodb
> brew services start mongodb-community
> ```

### Install

```bash
# Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate   # macOS/Linux
# .venv\Scripts\activate    # Windows

# Install the package
pip install -e .

# Install Playwright browsers (required for JS-rendered pages)
playwright install
```

### Configure

```bash
cp .env.example .env
# Edit .env with your MongoDB URI and preferences
```

## Usage

### Manual scrape (all sources)

```bash
news-hub run
```

### Scrape a single source

```bash
news-hub run-source techcrunch
```

### Limit the number of articles fetched

Articles are sorted by published date (newest first), so the limit always fetches the most recent articles.

```bash
# Fetch the 5 most recent new articles per source
news-hub run -n 5

# Fetch the 10 most recent new articles from a specific source
news-hub run-source techcrunch --limit 10
```

### Start the cron scheduler (APScheduler)

```bash
news-hub schedule
```

### Run using System Cron (Linux/macOS)

For production environments, you can use the system cron scheduler instead of the built-in python scheduler to run sources at varying frequencies based on their update rate. 

We provide a `run_scrapers.sh` script that categorizes sources into `hourly`, `daily`, and `weekly` buckets to optimize load.

To set this up, run `crontab -e` and add the following lines (adjust the paths to your project):

```bash
# Run high-frequency news sites every hour
0 * * * * /path/to/news-hub/run_scrapers.sh hourly >> /path/to/news-hub/cron.log 2>&1

# Run daily aggregators and general news once a day at 2:00 AM
0 2 * * * /path/to/news-hub/run_scrapers.sh daily >> /path/to/news-hub/cron.log 2>&1

# Run low-frequency research and engineering blogs once a week on Sunday at 3:00 AM
0 3 * * 0 /path/to/news-hub/run_scrapers.sh weekly >> /path/to/news-hub/cron.log 2>&1
```

### List registered sources

```bash
news-hub list-sources
```

### Browse article images (Streamlit GUI)

Launches a browser-based image gallery showing the `og_image` for each scraped article, grouped by source.

```bash
# Install the dev extras (first time only)
pip install -e ".[dev]"

# Launch the gallery
streamlit run src/image_viewer.py
```

Opens at `http://localhost:8501`. Use the sidebar to filter by source and adjust how many articles are shown. Articles with no stored image display a placeholder.

### Check for new articles

Compares the live feed for each source against the database and reports how many new articles have been published since the last stored article's published date:

```bash
# Check all sources
news-hub check-new

# Check a single source
news-hub check-new --source techcrunch
news-hub check-new -s arxiv
```

Example output:

```
Source      : techcrunch
Latest in DB: 'OpenAI Releases GPT-5'
Last updated: 2026-03-24 08:15 UTC
Feed total  : 20
New articles: 3

...

+---------------+----------------------+------------+--------------+
| Source        | Last Updated         | Feed Total | New Articles |
+---------------+----------------------+------------+--------------+
| techcrunch    | 2026-03-24 08:15 UTC |         20 |            3 |
| theverge      | 2026-03-24 07:00 UTC |         15 |            1 |
| venturebeat   | 2026-03-23 22:45 UTC |         25 |            0 |
+---------------+----------------------+------------+--------------+
```

> The consolidated table is only shown when checking multiple sources.

Fields:

| Field          | Description                                                         |
| -------------- | ------------------------------------------------------------------- |
| `Source`       | Registered source name                                              |
| `Latest in DB` | Title of the most recently stored article                           |
| `Last updated` | `published_date` (or `scraped_at`) of that article                  |
| `Feed total`   | Number of articles currently in the live feed                       |
| `New articles` | Feed entries published after the latest date stored in the database |

## Article Schema

Each scraped article is stored with the following fields:

| Field               | Type       | Description                                  |
| ------------------- | ---------- | -------------------------------------------- |
| `url`               | `str`      | Original article URL                         |
| `url_key`           | `str`      | SHA-256 hash of URL (used for deduplication) |
| `title`             | `str`      | Article title                                |
| `author`            | `str`      | Author name                                  |
| `tags`              | `list`     | Tags / categories                            |
| `published_date`    | `datetime` | Publication date                             |
| `og_image`          | `bytes`    | Open Graph image data                        |
| `og_image_mimetype` | `str`      | MIME type of the image                       |
| `body`              | `str`      | Full article body text                       |
| `description`       | `str`      | Short description / summary                  |
| `source_name`       | `str`      | Source identifier                            |
| `scraped_at`        | `datetime` | Timestamp of when the article was scraped    |
| `status`            | `str`      | `"ok"` or `"error"`                          |
| `error_message`     | `str`      | Error details (if status is `"error"`)       |

Each scrape cycle is also logged in the `scrape_runs` collection with start/end time, article counts, and any errors.

## Adding a New Source

1. Create a new file in `src/scrapers/` (e.g., `my_source.py`).
2. Extend `BaseScraper` and implement `discover_article_urls()`.
3. Import your class and add it to `SCRAPER_CLASSES` in `src/scrapers/registry.py`.

The base scraper provides built-in support for HTTP fetching with retry/backoff, rate limiting, Playwright-based rendering for JS-heavy pages, JSON-LD parsing, Open Graph metadata extraction, and sitemap discovery — so most scrapers only need to implement URL discovery.

No changes to core logic required.

## Environment Variables

| Variable           | Default                     | Description                          |
| ------------------ | --------------------------- | ------------------------------------ |
| `MONGO_URI`        | `mongodb://localhost:27017` | MongoDB connection string            |
| `MONGO_DB`         | `news_hub`                  | Database name                        |
| `SCRAPE_CRON`      | `0 */2 * * *`               | Cron schedule (every 2 hours)        |
| `REQUEST_TIMEOUT`  | `30`                        | HTTP request timeout in seconds      |
| `RETRY_MAX`        | `3`                         | Max retries on transient failures    |
| `RATE_LIMIT_DELAY` | `2.0`                       | Min seconds between same-domain reqs |
| `LOG_LEVEL`        | `INFO`                      | Log level (DEBUG, INFO, WARN, ERROR) |
