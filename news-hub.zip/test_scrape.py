import requests
from bs4 import BeautifulSoup

def test_github():
    print("Testing GitHub...")
    r = requests.get("https://github.com/trending")
    soup = BeautifulSoup(r.text, "html.parser")
    rows = soup.find_all("article", class_="Box-row")
    urls = []
    for row in rows:
        a = row.find("h2").find("a")
        if a and a.has_attr("href"):
            urls.append("https://github.com" + a["href"])
    print(f"Found {len(urls)} urls: {urls[:3]}")

def test_hf():
    print("Testing HuggingFace...")
    r = requests.get("https://huggingface.co/models?sort=trending")
    soup = BeautifulSoup(r.text, "html.parser")
    # Actually HF is usually client side rendered or has a specific class
    # Let's see what we can find
    articles = soup.find_all("article")
    print(f"Found {len(articles)} articles")
    for a in articles:
        link = a.find("a")
        if link and link.has_attr("href"):
            print("https://huggingface.co" + link["href"])
            break

test_github()
test_hf()
