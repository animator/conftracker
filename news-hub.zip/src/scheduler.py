"""APScheduler-based cron scheduler for periodic scraping (FR-1, FR-11)."""

from __future__ import annotations

from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger

from config import config
from logger import get_logger
from scrape_runner import run_all

log = get_logger(__name__)


def start_scheduler() -> None:
    """Start the blocking scheduler using the SCRAPE_CRON expression."""
    scheduler = BlockingScheduler()
    cron_expr = config.scrape_cron  # e.g. "0 */2 * * *"
    parts = cron_expr.split()

    trigger = CronTrigger(
        minute=parts[0],
        hour=parts[1],
        day=parts[2],
        month=parts[3],
        day_of_week=parts[4],
    )
    scheduler.add_job(run_all, trigger, id="scrape_all", replace_existing=True)
    log.info("scheduler_started", cron=cron_expr)

    # Run once immediately on startup, then follow cron
    run_all()

    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        log.info("scheduler_stopped")
        scheduler.shutdown()
