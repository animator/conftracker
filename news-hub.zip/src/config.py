"""Application configuration loaded from environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Config:
    mongo_uri: str = field(default_factory=lambda: os.environ.get(
        "MONGO_URI", "mongodb://localhost:27017"))
    mongo_db: str = field(
        default_factory=lambda: os.environ.get("MONGO_DB", "news_hub"))
    scrape_cron: str = field(
        default_factory=lambda: os.environ.get("SCRAPE_CRON", "0 */2 * * *"))
    request_timeout: int = field(default_factory=lambda: int(
        os.environ.get("REQUEST_TIMEOUT", "30")))
    retry_max: int = field(default_factory=lambda: int(
        os.environ.get("RETRY_MAX", "3")))
    rate_limit_delay: float = field(default_factory=lambda: float(
        os.environ.get("RATE_LIMIT_DELAY", "2.0")))
    log_level: str = field(
        default_factory=lambda: os.environ.get("LOG_LEVEL", "INFO"))


config = Config()
