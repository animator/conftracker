"""Structured logging helpers for scraper output."""

from __future__ import annotations

import csv
import io
import logging
import sys

import structlog

from config import config


_csv_header_written = False


def setup_logging() -> None:
    """Configure structlog for JSON output."""
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    root = logging.getLogger()
    root.setLevel(getattr(logging, config.log_level.upper(), logging.INFO))

    if not root.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter("%(message)s"))
        root.addHandler(handler)


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Return a named structlog logger."""
    return structlog.get_logger(name)


def _csv_line(values: list[str]) -> str:
    """Render a single CSV row."""
    buffer = io.StringIO()
    csv.writer(buffer).writerow(values)
    return buffer.getvalue().rstrip("\r\n")


def log_scrape_csv_row(index: int, total: int, url: str, fetch_success: bool, db_insert_success: bool) -> None:
    """Emit a simple CSV row for a scraped article URL."""
    global _csv_header_written

    csv_log = logging.getLogger("scrape_csv")
    if not _csv_header_written:
        csv_log.info(
            _csv_line(
                ["index/total", "url", "fetch_success", "db_insert_success"])
        )
        _csv_header_written = True

    csv_log.info(
        _csv_line(
            [
                f"{index}/{total}",
                url,
                str(fetch_success).lower(),
                str(db_insert_success).lower(),
            ]
        )
    )


def log_scrape_start_summary(source: str, start_fetching_count: int) -> None:
    """Emit the initial discovery summary for a scrape run."""
    summary_log = logging.getLogger("scrape_summary")
    summary_log.info(
        f"source: {source}, start fetching: {start_fetching_count}")


def log_scrape_complete_summary(source: str, fetch_success_count: int, insert_success_count: int) -> None:
    """Emit the final success summary for a scrape run."""
    summary_log = logging.getLogger("scrape_summary")
    summary_log.info(
        f"source: {source}, fetch success - {fetch_success_count}, insert success - {insert_success_count}"
    )
