"""Scraper for analyticsindiamag.com.

The curated RSS feed already includes the article body, author, summary, and
image metadata, so scraping builds records directly from feed entries.
"""

from __future__ import annotations

from typing import Any

from bs4 import BeautifulSoup

from logger import get_logger, log_scrape_start_summary
from models import Article
from scrapers.base import FeedBasedScraper

log = get_logger(__name__)


class AnalyticsIndiaMagScraper(FeedBasedScraper):
    source_name = "analyticsindiamag"
    base_url = "https://analyticsindiamag.com"
    collection_name = "analyticsindiamag"

    # Curated RSS feed used for discovery and feed-backed article extraction.
    FEED_URL = "https://zdpdvwhvukelzzbzbjvh.supabase.co/functions/v1/rss-feed"
    feed_error_event = "aim_feed_failed"

    # Backup: latest news sub-sitemap
    # SITEMAP_URL = "https://analyticsindiamag.com/ai-news-sitemap.xml"

    def discover_article_urls(self) -> list[str]:
        urls = self._discover_from_feed()
        if urls:
            log.debug("rss_discovery_ok", count=len(urls))
            log.debug("discovered_urls", urls=urls[:5])
            return urls
        log.warning("rss_empty_falling_back_to_sitemap")
        return []  # self.fetch_sitemap_urls(self.SITEMAP_URL, max_urls=100)

    def parse_article_page(self, url: str) -> Article:
        raise NotImplementedError(
            f"{self.__class__.__name__} is feed-only and does not parse individual article pages: {url}"
        )

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)

        description = (entry.get("summary") or entry.get(
            "description") or "").strip()
        body = self._clean_feed_body(entry)
        image_url = self._feed_image_url(entry)
        og_bytes, og_mime = self._download_image(image_url)

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=self._feed_author(entry),
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=body,
            description=description,
            source_name=self.source_name,
        )

    def _feed_author(self, entry: Any) -> str | None:
        authors = entry.get("authors") or []
        names = [author.get("name", "").strip()
                 for author in authors if author.get("name")]
        if names:
            return ", ".join(names)

        author = (entry.get("author") or "").strip()
        return author or None

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _feed_image_url(self, entry: Any) -> str | None:
        for media in entry.get("media_content", []):
            url = (media.get("url") or "").strip()
            if url:
                return url

        for enclosure in entry.get("enclosures", []):
            url = (enclosure.get("href") or enclosure.get("url") or "").strip()
            if url:
                return url

        return None

    def _clean_feed_body(self, entry: Any) -> str:
        fragments = entry.get("content") or []
        html = ""
        if fragments:
            html = fragments[0].get("value", "") or ""
        if not html:
            html = entry.get("summary") or entry.get("description") or ""
        if not html:
            return ""

        soup = BeautifulSoup(html, "lxml")
        for tag in soup.find_all(["script", "style", "iframe"]):
            tag.decompose()
        return soup.get_text(separator="\n", strip=True)
