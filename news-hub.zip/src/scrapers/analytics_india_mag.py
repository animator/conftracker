"""Scraper for analyticsindiamag.com.

The site is a React/Next.js SPA with Cloudflare protection, so individual
article pages are fetched via Playwright headless Chromium.

Primary discovery uses a curated RSS feed; the sitemap is kept as a fallback.
"""

from __future__ import annotations

from datetime import datetime, timezone

from bs4 import BeautifulSoup

from logger import get_logger
from models import Article
from scrapers.base import BaseScraper

log = get_logger(__name__)


class AnalyticsIndiaMagScraper(BaseScraper):
    source_name = "analyticsindiamag"
    base_url = "https://analyticsindiamag.com"
    collection_name = "analyticsindiamag"

    # Primary: curated RSS feed (used by BaseScraper._discover_from_feed)
    FEED_URL = "https://zdpdvwhvukelzzbzbjvh.supabase.co/functions/v1/rss-feed"

    # Backup: latest news sub-sitemap
    # SITEMAP_URL = "https://analyticsindiamag.com/ai-news-sitemap.xml"

    # CSS selectors for the rendered React content
    _CONTENT_SELECTOR = "article, [class*='article'], [class*='content'], main"

    def discover_article_urls(self) -> list[str]:
        urls = self._discover_from_feed()
        if urls:
            log.info("rss_discovery_ok", count=len(urls))
            return urls
        log.warning("rss_empty_falling_back_to_sitemap")
        return []  # self.fetch_sitemap_urls(self.SITEMAP_URL, max_urls=100)

    def parse_article_page(self, url: str) -> Article:
        """Use Playwright to render the SPA and extract article content."""
        html = self.fetch_rendered(url, wait_selector="h1", timeout_ms=30000)
        soup = BeautifulSoup(html, "lxml")

        jld = self._parse_json_ld(soup) or {}

        # Title: prefer JSON-LD headline, then first <h1>
        title = jld.get("headline") or self._og_meta(soup, "og:title") or ""
        if not title:
            h1 = soup.find("h1")
            title = h1.get_text(strip=True) if h1 else ""

        description = jld.get("description") or self._og_meta(
            soup, "og:description") or ""

        author = self._extract_author(jld)
        if not author:
            # Try common author containers in the React markup
            for sel in ["[class*='author']", "[class*='byline']"]:
                el = soup.select_one(sel)
                if el:
                    author = el.get_text(strip=True)
                    break

        published_date = self._parse_date(
            jld.get("datePublished") or jld.get("dateModified"))

        tags = self._extract_tags(soup, jld)

        og_image_url = jld.get("image") or self._og_meta(
            soup, "og:image") or ""
        if isinstance(og_image_url, dict):
            og_image_url = og_image_url.get("url", "")
        if isinstance(og_image_url, list):
            og_image_url = og_image_url[0] if og_image_url else ""
        og_bytes, og_mime = self._download_image(og_image_url or None)

        body = self._extract_aim_body(soup)

        return Article(
            url=url,
            url_key=self.url_key(url),
            title=title.strip(),
            author=author,
            tags=tags,
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=body,
            description=description.strip(),
            source_name=self.source_name,
        )

    def _extract_aim_body(self, soup: BeautifulSoup) -> str:
        """Extract article body from the hydrated React DOM."""
        # AIM renders content inside <article> or a div with common class patterns
        for selector in [
            "article",
            "[class*='article-content']",
            "[class*='articleBody']",
            "[class*='post-content']",
            "[class*='entry-content']",
            "[class*='storyContent']",
            "main",
        ]:
            el = soup.select_one(selector)
            if el:
                for tag in el.find_all(["script", "style", "nav", "aside", "footer",
                                        "header", "figure", "iframe", "button"]):
                    tag.decompose()
                text = el.get_text(separator="\n", strip=True)
                if len(text) > 200:
                    return text
        return ""
