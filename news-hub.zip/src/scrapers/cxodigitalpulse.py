"""Scraper for CXO Digital Pulse.

The RSS feed already includes the article description, full body, author,
publication date, and lead image, so scraping builds records directly from
feed entries.
"""

from __future__ import annotations

import re
from typing import Any

from bs4 import BeautifulSoup

from logger import get_logger, log_scrape_start_summary
from models import Article
from scrapers.base import FeedBasedScraper

log = get_logger(__name__)


class CxoDigitalPulseScraper(FeedBasedScraper):
    source_name = "cxodigitalpulse"
    base_url = "https://www.cxodigitalpulse.com"
    collection_name = "cxodigitalpulse"

    FEED_URL = "https://www.cxodigitalpulse.com/feed/"
    feed_error_event = "cxo_feed_failed"

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)
        body, image_url = self._clean_body_and_extract_image(entry)
        og_bytes, og_mime = self._download_image(image_url)

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=self._feed_author(entry),
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=body,
            description=self._clean_description(entry),
            source_name=self.source_name,
        )

    def _feed_author(self, entry: Any) -> str | None:
        authors = entry.get("authors") or []
        names = [author.get("name", "").strip()
                 for author in authors if author.get("name")]
        if names:
            return ", ".join(names)

        author = (entry.get("author") or "").strip()
        return author or None

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _clean_description(self, entry: Any) -> str:
        html = entry.get("summary") or entry.get("description") or ""
        return self._clean_feed_html(html)

    def _clean_body_and_extract_image(self, entry: Any) -> tuple[str, str | None]:
        fragments = entry.get("content") or []
        html = fragments[0].get("value", "") if fragments else ""
        if not html:
            html = entry.get("summary") or entry.get("description") or ""
        if not html:
            return "", None

        soup = BeautifulSoup(html, "lxml")
        for tag in soup.find_all(["script", "style", "iframe"]):
            tag.decompose()

        image_url: str | None = None
        first_paragraph = soup.find("p")
        if first_paragraph is not None:
            first_image = first_paragraph.find("img")
            if first_image is not None:
                image_url = (first_image.get("src") or "").strip() or None
                first_paragraph.decompose()

        self._remove_footer_paragraphs(soup)
        return self._extract_block_text(soup), image_url

    def _clean_feed_html(self, html: str) -> str:
        if not html:
            return ""

        soup = BeautifulSoup(html, "lxml")
        for tag in soup.find_all(["script", "style", "iframe"]):
            tag.decompose()
        self._remove_footer_paragraphs(soup)
        return self._extract_block_text(soup)

    def _remove_footer_paragraphs(self, soup: BeautifulSoup) -> None:
        for paragraph in soup.find_all("p"):
            text = paragraph.get_text(" ", strip=True)
            if text.startswith("The post ") and "appeared first on" in text:
                paragraph.decompose()

    def _extract_block_text(self, soup: BeautifulSoup) -> str:
        blocks = []
        for tag in soup.find_all(["p", "li", "h1", "h2", "h3", "h4"]):
            text = tag.get_text(" ", strip=True)
            if text:
                blocks.append(self._normalize_text(text))
        if blocks:
            return "\n".join(blocks)
        return self._normalize_text(soup.get_text(" ", strip=True))

    def _normalize_text(self, text: str) -> str:
        text = re.sub(r"\s+([,.;:!?])", r"\1", text)
        return re.sub(r"\s+", " ", text).strip()
