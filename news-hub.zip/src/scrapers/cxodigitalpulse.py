"""Scraper for CXO Digital Pulse."""

from __future__ import annotations

from scrapers.base import BaseScraper


class CxoDigitalPulseScraper(BaseScraper):
    source_name = "cxodigitalpulse"
    base_url = "https://www.cxodigitalpulse.com"
    collection_name = "cxodigitalpulse"

    FEED_URL = "https://www.cxodigitalpulse.com/feed/"

    def discover_article_urls(self) -> list[str]:
        resp = self.fetch(self.base_url)
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(resp.text, "lxml")
        urls = []
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if not href.startswith(self.base_url):
                continue
            
            path = href[len(self.base_url):].strip("/")
            if not path:
                continue
                
            ignored_prefixes = (
                "category", "infographics", "advertorials", "upcoming-events",
                "newsletters", "submit-your-article", "about-us", "contact-us",
                "cookie-policy", "privacy-policy", "terms-of-use", "cxo-tv",
                "whitepaper-reports", "author", "tag"
            )
            
            if any(path.startswith(prefix) for prefix in ignored_prefixes):
                continue
                
            if len(path) > 20 and href not in urls:
                urls.append(href)
                
        return urls[:20]
