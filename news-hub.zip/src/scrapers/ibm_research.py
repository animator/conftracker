"""Scraper for IBM Research blog."""

from __future__ import annotations

from scrapers.base import BaseScraper


class IbmResearchScraper(BaseScraper):
    source_name = "ibm_research"
    base_url = "https://research.ibm.com"
    collection_name = "ibm_research"

    FEED_URL = "https://research.ibm.com/rss?fid=rss"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
