"""Scraper for IBM Research blog.

The feed provides the article URL, publication date, and tags. The article page
provides the author, description, image, and full article text.
"""

from __future__ import annotations

import re
from typing import Any

from bs4 import BeautifulSoup

from logger import get_logger, log_scrape_start_summary
from models import Article
from scrapers.base import FeedBasedScraper

log = get_logger(__name__)


class IbmResearchScraper(FeedBasedScraper):
    source_name = "ibm_research"
    base_url = "https://research.ibm.com"
    collection_name = "ibm_research"

    FEED_URL = "https://research.ibm.com/rss?fid=rss"

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)

        author, description, body, image_url = self._fetch_page_content(
            entry.get("link", ""))
        og_bytes, og_mime = self._download_image(image_url)

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=author,
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=body,
            description=description,
            source_name=self.source_name,
        )

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _fetch_page_content(self, url: str) -> tuple[str | None, str, str, str | None]:
        resp = self.fetch(url)
        soup = BeautifulSoup(resp.text, "lxml")
        jld = self._parse_json_ld(soup) or {}

        main_container = soup.select_one("#main-content > div")
        body = self._extract_main_content(
            main_container) if main_container else ""

        image_url = jld.get("image") or self._og_meta(soup, "og:image") or ""
        if isinstance(image_url, dict):
            image_url = image_url.get("url", "")
        if isinstance(image_url, list):
            image_url = image_url[0] if image_url else ""

        description = (jld.get("description") or self._og_meta(
            soup, "og:description") or "").strip()
        author = self._extract_author(jld)
        return author, description, body, image_url or None

    def _extract_main_content(self, container: BeautifulSoup) -> str:
        for unwanted in container.find_all(["script", "style", "iframe", "aside", "nav"]):
            unwanted.decompose()

        blocks = []
        for tag in container.find_all(["p", "li", "h2", "h3", "h4", "blockquote"]):
            text = self._normalize_text(tag.get_text(" ", strip=True))
            if text:
                blocks.append(text)
        if blocks:
            return "\n".join(blocks)
        return self._normalize_text(container.get_text(" ", strip=True))

    def _normalize_text(self, text: str) -> str:
        text = re.sub(r"\s+([,.;:!?])", r"\1", text)
        return re.sub(r"\s+", " ", text).strip()
