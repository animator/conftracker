"""Scraper for infoq.com.

The feed provides the article title, author, publication date, tags, summary,
and header image. The article page provides the full body text.
"""

from __future__ import annotations

import re
from typing import Any

from bs4 import BeautifulSoup

from logger import get_logger, log_scrape_start_summary
from models import Article
from scrapers.base import FeedBasedScraper

log = get_logger(__name__)


class InfoQScraper(FeedBasedScraper):
    source_name = "infoq"
    base_url = "https://www.infoq.com"
    collection_name = "infoq"

    FEED_URL = "https://feed.infoq.com/"

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)
        description, image_url = self._feed_description_and_image(entry)
        og_bytes, og_mime = self._download_image(image_url)
        body = self._fetch_page_body(entry.get("link", ""))

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=self._feed_author(entry),
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=body,
            description=description,
            source_name=self.source_name,
        )

    def _feed_author(self, entry: Any) -> str | None:
        authors = entry.get("authors") or []
        names = [author.get("name", "").strip()
                 for author in authors if author.get("name")]
        if names:
            return ", ".join(names)
        author = (entry.get("author") or "").strip()
        return author or None

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _feed_description_and_image(self, entry: Any) -> tuple[str, str | None]:
        html = entry.get("summary") or entry.get("description") or ""
        if not html:
            return "", None

        soup = BeautifulSoup(html, "lxml")
        image = soup.find("img")
        image_url = (image.get("src") or "").strip() if image else ""
        if image:
            image.decompose()

        for tag in soup.find_all(["script", "style", "iframe"]):
            tag.decompose()

        text = soup.get_text(" ", strip=True)
        text = re.sub(r"\s+By\s+[^.]+$", "", text).strip()
        text = re.sub(r"\s+", " ", text)
        return text, image_url or None

    def _fetch_page_body(self, url: str) -> str:
        resp = self.fetch(url)
        soup = BeautifulSoup(resp.text, "lxml")
        container = soup.select_one("div.article__data")
        if not container:
            return ""

        for unwanted in container.find_all(["script", "style", "iframe", "aside", "nav"]):
            unwanted.decompose()
        for author_section in container.select("div.author-section-full"):
            author_section.decompose()

        blocks = []
        for tag in container.find_all(["p", "li", "h2", "h3", "h4", "blockquote"]):
            text = self._normalize_text(tag.get_text(" ", strip=True))
            if text:
                blocks.append(text)
        if blocks:
            return "\n".join(blocks)
        return self._normalize_text(container.get_text(" ", strip=True))

    def _normalize_text(self, text: str) -> str:
        text = re.sub(r"\s+([,.;:!?])", r"\1", text)
        return re.sub(r"\s+", " ", text).strip()
