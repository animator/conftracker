"""Scraper for infoq.com."""

from __future__ import annotations

from scrapers.base import BaseScraper


class InfoQScraper(BaseScraper):
    source_name = "infoq"
    base_url = "https://www.infoq.com"
    collection_name = "infoq"

    FEED_URL = "https://feed.infoq.com/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
