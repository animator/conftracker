"""Scraper for Hugging Face blog.

The feed provides the article title and publication date. The article page
provides the Open Graph image and the full article body.
"""

from __future__ import annotations

import re
from typing import Any

from bs4 import BeautifulSoup, NavigableString

from logger import get_logger, log_scrape_start_summary
from models import Article
from scrapers.base import FeedBasedScraper

log = get_logger(__name__)


class HuggingfaceBlogScraper(FeedBasedScraper):
    source_name = "huggingface_blog"
    base_url = "https://huggingface.co/blog"
    collection_name = "huggingface_blog"

    FEED_URL = "https://huggingface.co/blog/feed.xml"

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)
        author, body, og_image_url = self._fetch_page_content(
            entry.get("link", ""))
        og_bytes, og_mime = self._download_image(og_image_url)

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=author,
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=body,
            description=None,
            source_name=self.source_name,
        )

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _fetch_page_content(self, url: str) -> tuple[str | None, str, str | None]:
        resp = self.fetch(url)
        soup = BeautifulSoup(resp.text, "lxml")

        body_container = soup.select_one("div.blog-content")
        body = self._extract_blog_body(
            body_container) if body_container else ""

        return None, body, self._og_meta(soup, "og:image")

    def _extract_blog_body(self, container: BeautifulSoup) -> str:
        for unwanted in container.find_all(["script", "style", "iframe", "aside"]):
            unwanted.decompose()

        self._remove_leading_blog_chrome(container)

        blocks = []
        intro = self._extract_leading_intro(container)
        if intro:
            blocks.append(intro)
        for tag in container.find_all(["p", "li", "h2", "h3", "h4", "pre", "blockquote"]):
            text = self._normalize_text(tag.get_text(" ", strip=True))
            if text:
                blocks.append(text)
        if blocks:
            return "\n".join(blocks)
        return self._normalize_text(container.get_text(" ", strip=True))

    def _extract_leading_intro(self, container: BeautifulSoup) -> str:
        inline_parts: list[str] = []
        block_tags = {"p", "li", "h2", "h3",
                      "h4", "pre", "blockquote", "ul", "ol"}

        for child in container.children:
            if isinstance(child, NavigableString):
                text = self._normalize_text(str(child))
                if text and not self._skip_intro_fragment(text):
                    inline_parts.append(text)
                continue

            if not getattr(child, "name", None):
                continue

            if child.name in block_tags:
                break

            text = self._normalize_text(child.get_text(" ", strip=True))
            if text and not self._skip_intro_fragment(text):
                inline_parts.append(text)

        intro = self._normalize_text(" ".join(inline_parts))
        return re.sub(r"^(?:[\[\]\-0-9]+\s*)+", "", intro).strip()

    def _remove_leading_blog_chrome(self, container: BeautifulSoup) -> None:
        nav = container.find("nav")
        if nav is None:
            return

        direct_nav_wrapper = nav
        while direct_nav_wrapper.parent is not container and direct_nav_wrapper.parent is not None:
            direct_nav_wrapper = direct_nav_wrapper.parent

        for child in list(container.children):
            if not getattr(child, "name", None):
                continue
            child.decompose()
            if child is direct_nav_wrapper:
                break

    def _normalize_text(self, text: str) -> str:
        text = re.sub(r"\s+([,.;:!?])", r"\1", text)
        return re.sub(r"\s+", " ", text).strip()

    def _skip_intro_fragment(self, text: str) -> bool:
        return bool(re.fullmatch(r"[\[\]\-0-9]+", text))
