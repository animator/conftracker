"""Scraper for Hugging Face blog."""

from __future__ import annotations

from scrapers.base import BaseScraper


class HuggingfaceBlogScraper(BaseScraper):
    source_name = "huggingface_blog"
    base_url = "https://huggingface.co/blog"
    collection_name = "huggingface_blog"

    FEED_URL = "https://huggingface.co/blog/feed.xml"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
