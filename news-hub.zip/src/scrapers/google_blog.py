"""Scraper for blog.google."""

from __future__ import annotations

from bs4 import BeautifulSoup

from scrapers.base import BaseScraper


class GoogleBlogScraper(BaseScraper):
    source_name = "google_blog"
    base_url = "https://blog.google"
    collection_name = "google_blog"

    FEED_URL = "https://blog.google/rss/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()

    def _extract_body(self, soup: BeautifulSoup) -> str:
        container = soup.select_one("div.module--text__article")
        if not container:
            return super()._extract_body(soup)

        for unwanted in container.find_all([
            "script",
            "style",
            "nav",
            "aside",
            "footer",
            "header",
            "figure",
            "iframe",
            "button",
        ]):
            unwanted.decompose()

        return container.get_text(separator="\n", strip=True)
