"""Scraper for blog.google."""

from __future__ import annotations

from scrapers.base import BaseScraper


class GoogleBlogScraper(BaseScraper):
    source_name = "google_blog"
    base_url = "https://blog.google"
    collection_name = "google_blog"

    FEED_URL = "https://blog.google/rss/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
