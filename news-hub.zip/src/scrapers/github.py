"""Scraper for github.com trending projects."""

from __future__ import annotations

import re
from datetime import datetime, timezone

from bs4 import BeautifulSoup

from db import get_db
from scrapers.base import BaseScraper, log


class GithubTrendingScraper(BaseScraper):
    source_name = "github"
    base_url = "https://github.com"
    collection_name = "github"
    manual_insert_mode = True

    def discover_article_urls(self) -> list[str]:
        # Not used because we override scrape()
        return []

    def scrape(self, existing_keys: set[str]):
        """Override scrape to extract data directly from trending pages and upsert."""
        db = get_db()
        collection = db[self.collection_name]

        # Ensure index on url for efficient upserts
        collection.create_index("url", unique=True)

        trending_urls = [
            "https://github.com/trending",
            "https://github.com/trending/python",
            "https://github.com/trending/javascript",
            "https://github.com/trending/c++",
            "https://github.com/trending/rust",
            "https://github.com/trending/typescript",
        ]
        self.last_discovered_url_count = len(trending_urls)

        seen_urls = set()
        today_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        for url in trending_urls:
            try:
                resp = self.fetch(url)
                soup = BeautifulSoup(resp.text, "lxml")
                for row in soup.find_all("article", class_="Box-row"):
                    h2 = row.find("h2")
                    if not h2:
                        continue
                    a = h2.find("a")
                    if not a or not a.get("href"):
                        continue

                    project_url = f"https://github.com{a['href']}"

                    if project_url in seen_urls:
                        continue
                    seen_urls.add(project_url)

                    # Extract name
                    name = a.get_text(strip=True)
                    name = re.sub(r'\s+', ' ', name)

                    # Extract description
                    desc_tag = row.find("p", class_="col-9")
                    description = desc_tag.get_text(
                        strip=True) if desc_tag else ""

                    # Extract stars
                    stars = 0
                    stars_tag = row.find(
                        "a", href=lambda x: x and x.endswith("/stargazers"))
                    if stars_tag:
                        stars_text = stars_tag.get_text(
                            strip=True).replace(',', '')
                        try:
                            stars = int(stars_text)
                        except ValueError:
                            pass

                    existing = collection.find_one({"url": project_url})
                    if existing:
                        update_data = {
                            "description": description,
                            "stars": stars,
                            "latest_trending_date": today_date
                        }

                        trending_on = existing.get("trending_on", [])
                        if today_date not in trending_on:
                            update_data["trending_on"] = trending_on + \
                                [today_date]

                        collection.update_one(
                            {"_id": existing["_id"]},
                            {"$set": update_data}
                        )
                        log.debug("github_trending_updated", url=project_url)
                    else:
                        new_doc = {
                            "url": project_url,
                            "url_key": self.url_key(project_url),
                            "title": name,
                            "author": name.split()[0],
                            "description": description,
                            "body": None,
                            "stars": stars,
                            "latest_trending_date": today_date,
                            "trending_on": [today_date],
                            "source_name": self.source_name,
                            "scraped_at": datetime.now(timezone.utc),
                            "status": "ok",
                            "selected": None
                        }
                        collection.insert_one(new_doc)
                        log.debug("github_trending_inserted", url=project_url)

            except Exception as e:
                log.error("github_trending_fetch_failed",
                          url=url, error=str(e))

        # Yield an empty generator since we handled DB inserts manually
        yield from ()
