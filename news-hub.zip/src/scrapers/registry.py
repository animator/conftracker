"""Central registry of all source scrapers (NFR-5).

To add a new source, import its class and append it to SCRAPER_CLASSES.
No changes to core logic required.
"""

from __future__ import annotations

from scrapers.analytics_india_mag import AnalyticsIndiaMagScraper
from scrapers.arxiv import ArxivScraper
from scrapers.google_blog import GoogleBlogScraper
from scrapers.infoq import InfoQScraper
from scrapers.mashable import MashableScraper
from scrapers.nvidia_blog import NvidiaBlogScraper
from scrapers.techcrunch import TechCrunchScraper
from scrapers.theverge import TheVergeScraper
from scrapers.venturebeat import VentureBeatScraper

SCRAPER_CLASSES = [
    AnalyticsIndiaMagScraper,
    ArxivScraper,
    GoogleBlogScraper,
    NvidiaBlogScraper,
    InfoQScraper,
    # MashableScraper,
    VentureBeatScraper,
    TechCrunchScraper,
    TheVergeScraper,
]

SCRAPER_CLASSES_WO_ARXIV = [
    c for c in SCRAPER_CLASSES if c is not ArxivScraper]
