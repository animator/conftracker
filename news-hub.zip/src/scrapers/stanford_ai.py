"""Scraper for Stanford AI blog."""

from __future__ import annotations

from scrapers.base import BaseScraper


class StanfordAiScraper(BaseScraper):
    source_name = "stanford_ai"
    base_url = "https://ai.stanford.edu/blog"
    collection_name = "stanford_ai"

    FEED_URL = "https://ai.stanford.edu/blog/feed.xml"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
