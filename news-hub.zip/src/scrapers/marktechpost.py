"""Scraper for MarkTechPost."""

from __future__ import annotations

from scrapers.base import BaseScraper


class MarkTechPostScraper(BaseScraper):
    source_name = "marktechpost"
    base_url = "https://www.marktechpost.com"
    collection_name = "marktechpost"

    FEED_URL = "https://www.marktechpost.com/feed/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
