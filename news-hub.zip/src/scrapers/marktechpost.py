"""Scraper for MarkTechPost.

The RSS feed provides the article title, author, publication date, tags,
summary, and full article HTML. The article page is only fetched to resolve the
Open Graph image.
"""

from __future__ import annotations

import re
from typing import Any

from bs4 import BeautifulSoup

from logger import get_logger, log_scrape_start_summary
from models import Article
from scrapers.base import FeedBasedScraper

log = get_logger(__name__)


class MarkTechPostScraper(FeedBasedScraper):
    source_name = "marktechpost"
    base_url = "https://www.marktechpost.com"
    collection_name = "marktechpost"

    FEED_URL = "https://www.marktechpost.com/feed/"

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)
        og_bytes, og_mime = self._fetch_page_image(entry.get("link", ""))

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=self._feed_author(entry),
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=self._clean_body(entry),
            description=self._clean_description(entry),
            source_name=self.source_name,
        )

    def _feed_author(self, entry: Any) -> str | None:
        authors = entry.get("authors") or []
        names = [author.get("name", "").strip()
                 for author in authors if author.get("name")]
        if names:
            return ", ".join(names)

        author = (entry.get("author") or "").strip()
        return author or None

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _clean_description(self, entry: Any) -> str:
        html = entry.get("summary") or entry.get("description") or ""
        if not html:
            return ""

        soup = BeautifulSoup(html, "lxml")
        self._strip_common_feed_noise(soup)
        for paragraph in soup.find_all("p"):
            if self._is_boilerplate_paragraph(paragraph.get_text(" ", strip=True)):
                paragraph.decompose()

        text = soup.get_text(" ", strip=True)
        return re.sub(r"\s+", " ", text).strip()

    def _clean_body(self, entry: Any) -> str:
        fragments = entry.get("content") or []
        html = fragments[0].get("value", "") if fragments else ""
        if not html:
            html = entry.get("summary") or entry.get("description") or ""
        if not html:
            return ""

        soup = BeautifulSoup(html, "lxml")
        self._strip_common_feed_noise(soup)

        for paragraph in soup.find_all("p"):
            text = paragraph.get_text(" ", strip=True)
            if self._is_boilerplate_paragraph(text) or self._is_promotional_paragraph(text):
                paragraph.decompose()

        blocks: list[str] = []
        for tag in soup.find_all(["p", "li", "h2", "h3", "h4", "blockquote", "pre"]):
            if tag.name == "pre":
                text = tag.get_text("\n", strip=True)
            else:
                text = self._normalize_text(tag.get_text(" ", strip=True))
            if text:
                blocks.append(text)

        if blocks:
            return "\n".join(blocks)
        return self._normalize_text(soup.get_text(" ", strip=True))

    def _strip_common_feed_noise(self, soup: BeautifulSoup) -> None:
        for tag in soup.find_all(["script", "style", "iframe", "hr"]):
            tag.decompose()

        for control in soup.select("div.control-language"):
            control.decompose()

        for paragraph in soup.find_all("p"):
            if not paragraph.get_text(" ", strip=True):
                paragraph.decompose()

    def _is_boilerplate_paragraph(self, text: str) -> bool:
        normalized = self._normalize_text(text)
        return normalized.startswith("The post ") and "appeared first on" in normalized

    def _is_promotional_paragraph(self, text: str) -> bool:
        normalized = self._normalize_text(text).lower()
        promo_markers = (
            "check out the full codes",
            "follow us on",
            "join our",
            "subscribe to",
            "telegram",
            "need to partner with us",
            "connect with us",
        )
        return any(marker in normalized for marker in promo_markers)

    def _fetch_page_image(self, url: str) -> tuple[bytes | None, str | None]:
        if not url:
            return None, None

        try:
            resp = self.fetch(url)
        except Exception as exc:
            log.warning("marktechpost_page_fetch_failed",
                        url=url, error=str(exc))
            return None, None

        soup = BeautifulSoup(resp.text, "lxml")
        return self._download_image(self._og_meta(soup, "og:image"))

    def _normalize_text(self, text: str) -> str:
        text = re.sub(r"\s+([,.;:!?])", r"\1", text)
        return re.sub(r"\s+", " ", text).strip()
