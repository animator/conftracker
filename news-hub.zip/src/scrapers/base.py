"""Base scraper with shared HTTP logic, retry, rate-limiting, and article parsing."""

from __future__ import annotations

import hashlib
import html as html_module
import json
import time
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any
from xml.etree import ElementTree

import requests
from bs4 import BeautifulSoup

from config import config
from logger import get_logger
from models import Article

log = get_logger(__name__)


class BaseScraper(ABC):
    """Abstract base every source scraper must extend."""

    # Subclasses MUST set these
    source_name: str = ""
    base_url: str = ""
    collection_name: str = ""

    def __init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": (
                    "Mozilla/5.0 (compatible; News/0.1; "
                    "+https://github.com/news)"
                ),
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
            }
        )
        self._last_request_time: float = 0.0
        # Persistent Playwright browser — lazily initialized, shared across articles
        self._pw = None
        self._pw_browser = None
        self._pw_context = None

    # ── HTTP helpers ─────────────────────────────────────────────

    def _rate_limit(self) -> None:
        """Enforce minimum delay between requests to the same domain (FR-16)."""
        elapsed = time.time() - self._last_request_time
        if elapsed < config.rate_limit_delay:
            time.sleep(config.rate_limit_delay - elapsed)

    def fetch(self, url: str, **kwargs: Any) -> requests.Response:
        """GET *url* with retry + exponential backoff (FR-14)."""
        self._rate_limit()
        last_exc: Exception | None = None
        for attempt in range(1, config.retry_max + 1):
            try:
                resp = self.session.get(
                    url, timeout=config.request_timeout, **kwargs)
                self._last_request_time = time.time()
                resp.raise_for_status()
                log.info("fetch_ok", url=url, status=resp.status_code)
                return resp
            except requests.exceptions.SSLError as exc:
                # Handle SSL errors by retrying with verfication disabled 
                log.warning("ssl_error_retry", url=url, attempt=attempt, error=str(exc))
                # retry with verification disabled 
                kwargs["verify"] = False
                # Also add a warning header to indicate insecure requests
                if "headers" not in kwargs:
                    kwargs["headers"] = {}
                kwargs["headers"]["X-Insecure-Request"] = "1"
                # continue loop to retry
                continue
            except (requests.ConnectionError, requests.Timeout, requests.HTTPError) as exc:
                last_exc = exc
                status = getattr(
                    getattr(exc, "response", None), "status_code", None)
                # Only retry on 5xx or connection/timeout errors
                if status is not None and 400 <= status < 500:
                    raise
                wait = 2**attempt
                log.warning(
                    "request_retry",
                    url=url,
                    attempt=attempt,
                    wait=wait,
                    error=str(exc),
                )
                time.sleep(wait)
        raise last_exc  # type: ignore[misc]

    def _ensure_browser(self):
        """Lazily start a shared Playwright browser + context."""
        if self._pw_browser is None:
            from playwright.sync_api import sync_playwright
            self._pw = sync_playwright().start()
            self._pw_browser = self._pw.chromium.launch(headless=True)
            self._pw_context = self._pw_browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/122.0.0.0 Safari/537.36"
                ),
                extra_http_headers={"Accept-Language": "en-US,en;q=0.9"},
            )

    def close_browser(self):
        """Shut down the shared Playwright browser (call at end of scrape cycle)."""
        if self._pw_browser is not None:
            self._pw_browser.close()
            self._pw_browser = None
            self._pw_context = None
        if self._pw is not None:
            self._pw.stop()
            self._pw = None

    def fetch_rendered(self, url: str, wait_selector: str | None = None, timeout_ms: int = 30000) -> str:
        """Fetch a JS-rendered page via Playwright headless Chromium and return the HTML.

        Reuses a single browser instance across multiple calls for performance.
        """
        self._rate_limit()
        self._ensure_browser()
        page = self._pw_context.new_page()
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
            if wait_selector:
                try:
                    page.wait_for_selector(wait_selector, timeout=timeout_ms)
                except Exception:
                    pass
            else:
                page.wait_for_timeout(3000)
            html = page.content()
        finally:
            page.close()
        self._last_request_time = time.time()
        return html

    def fetch_xml(self, url: str) -> ElementTree.Element:
        """Fetch and parse an XML document."""
        resp = self.fetch(url)
        return ElementTree.fromstring(resp.content)

    # ── URL key ──────────────────────────────────────────────────

    @staticmethod
    def url_key(url: str) -> str:
        """Derive a stable unique key from a URL (FR-7)."""
        return hashlib.sha256(url.encode()).hexdigest()

    # ── Common HTML parsing helpers ──────────────────────────────

    def _parse_json_ld(self, soup: BeautifulSoup) -> dict[str, Any] | None:
        """Extract the first JSON-LD block of type Article/NewsArticle/BlogPosting."""
        for tag in soup.find_all("script", type="application/ld+json"):
            try:
                data = json.loads(tag.string or "")
            except (json.JSONDecodeError, TypeError):
                continue
            # Handle @graph arrays
            items = data if isinstance(
                data, list) else data.get("@graph", [data])
            for item in items:
                t = item.get("@type", "")
                if isinstance(t, list):
                    types = t
                else:
                    types = [t]
                if any(
                    x in types
                    for x in ("Article", "NewsArticle", "BlogPosting", "TechArticle", "ScholarlyArticle", "ReportageNewsArticle")
                ):
                    return item
        return None

    def _og_meta(self, soup: BeautifulSoup, prop: str) -> str | None:
        tag = soup.find("meta", property=prop) or soup.find(
            "meta", attrs={"name": prop})
        # type: ignore[return-value]
        return tag["content"] if tag and tag.get("content") else None

    def _download_image(self, url: str | None) -> tuple[bytes | None, str | None]:
        """Download og:image and return (bytes, mimetype)."""
        if not url:
            return None, None
        try:
            resp = self.fetch(url)
            mimetype = resp.headers.get(
                "Content-Type", "image/jpeg").split(";")[0].strip()
            return resp.content, mimetype
        except Exception:
            log.warning("image_download_failed", url=url)
            return None, None

    def parse_article_page(self, url: str) -> Article:
        """Fetch a single article page and extract structured data (FR-3, FR-4)."""
        resp = self.fetch(url)
        return self._parse_html(url, resp.text)

    def _parse_html(self, url: str, html: str) -> Article:
        """Parse pre-fetched HTML and return an Article. Subclasses can call this
        after obtaining HTML via any means (requests, Playwright, etc.)."""
        soup = BeautifulSoup(html, "lxml")
        jld = self._parse_json_ld(soup) or {}

        title = html_module.unescape(
            jld.get("headline")
            or self._og_meta(soup, "og:title")
            or (soup.title.string if soup.title else "")
            or ""
        )
        description = html_module.unescape(
            jld.get("description")
            or self._og_meta(soup, "og:description")
            or ""
        )
        author = self._extract_author(jld)
        published_date = self._parse_date(jld.get("datePublished"))
        tags = self._extract_tags(soup, jld)
        og_image_url = jld.get("image", {})
        if isinstance(og_image_url, list):
            og_image_url = og_image_url[0] if og_image_url else ""
        if isinstance(og_image_url, dict):
            og_image_url = og_image_url.get("url", "")
        og_image_url = og_image_url or self._og_meta(soup, "og:image")
        og_bytes, og_mime = self._download_image(og_image_url)

        body = self._extract_body(soup)

        return Article(
            url=url,
            url_key=self.url_key(url),
            title=title.strip() if title else "",
            author=author,
            tags=tags,
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=body,
            description=description.strip() if description else "",
            source_name=self.source_name,
        )

    # ── Extraction helpers (overridable) ─────────────────────────

    def _extract_author(self, jld: dict[str, Any]) -> str | None:
        author = jld.get("author")
        if isinstance(author, list):
            return ", ".join(a.get("name", "") if isinstance(a, dict) else str(a) for a in author)
        if isinstance(author, dict):
            return author.get("name")
        if isinstance(author, str):
            return author
        return None

    @staticmethod
    def _parse_date(raw: str | None) -> datetime | None:
        if not raw:
            return None
        for fmt in (
            "%Y-%m-%dT%H:%M:%S%z",
            "%Y-%m-%dT%H:%M:%S.%f%z",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M%z",
            "%Y-%m-%d",
        ):
            try:
                return datetime.strptime(raw, fmt).replace(tzinfo=timezone.utc)
            except ValueError:
                continue
        return None

    def _extract_tags(self, soup: BeautifulSoup, jld: dict[str, Any]) -> list[str]:
        keywords = jld.get("keywords")
        if isinstance(keywords, list):
            return [k for k in keywords if k and str(k).lower() != "none"]
        if isinstance(keywords, str) and keywords.lower() != "none":
            return [k.strip() for k in keywords.split(",") if k.strip() and k.strip().lower() != "none"]
        # Fallback: meta keywords
        meta = soup.find("meta", attrs={"name": "keywords"})
        if meta and meta.get("content"):
            # type: ignore[index]
            return [
                k.strip()
                for k in meta["content"].split(",")  # type: ignore[index]
                if k.strip() and k.strip().lower() != "none"
            ]
        return []

    def _extract_body(self, soup: BeautifulSoup) -> str:
        """Extract visible article body text. Subclasses may override for specifics."""
        import re
        container = (
            soup.find("article")
            or soup.find("div", class_="entry-content")
            or soup.find("div", class_="article-body")
            or soup.find("div", attrs={"class": re.compile(r"(post|article|story|content)[_-]?(body|content|text)", re.I)})
            or soup.find("main")
        )
        if container:
            for unwanted in container.find_all(["script", "style", "nav", "aside", "footer", "header", "figure", "iframe"]):
                unwanted.decompose()
            return container.get_text(separator="\n", strip=True)
        return ""

    # ── Sitemap / feed helpers ───────────────────────────────────

    def _discover_from_feed(self, feed_url: str | None = None) -> list[str]:
        """Parse an RSS/Atom feed and return article URLs sorted by published date (newest first).

        Uses the class-level ``FEED_URL`` unless *feed_url* is given explicitly.
        """
        import feedparser  # type: ignore[import]

        url = feed_url or getattr(self, "FEED_URL", None)
        if not url:
            return []
        resp = self.fetch(url)
        feed = feedparser.parse(resp.text)
        entries = [e for e in feed.entries if e.get("link")]
        entries.sort(
            key=lambda e: e.get("published_parsed") or e.get(
                "updated_parsed") or (0,) * 9,
            reverse=True,
        )
        return [e.link for e in entries]

    def fetch_sitemap_urls(self, sitemap_url: str, max_urls: int = 200) -> list[str]:
        """Parse a sitemap XML and return article URLs (FR-2)."""
        try:
            root = self.fetch_xml(sitemap_url)
        except Exception:
            log.warning("sitemap_fetch_failed", url=sitemap_url)
            return []
        ns = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
        urls: list[str] = []
        # Handle sitemap index (references to sub-sitemaps)
        for sitemap in root.findall("sm:sitemap", ns):
            loc = sitemap.find("sm:loc", ns)
            if loc is not None and loc.text:
                urls.extend(self.fetch_sitemap_urls(
                    loc.text.strip(), max_urls - len(urls)))
                if len(urls) >= max_urls:
                    break
        # Handle urlset
        for url_el in root.findall("sm:url", ns):
            loc = url_el.find("sm:loc", ns)
            if loc is not None and loc.text:
                urls.append(loc.text.strip())
                if len(urls) >= max_urls:
                    break
        return urls[:max_urls]

    # ── Abstract interface ───────────────────────────────────────

    @abstractmethod
    def discover_article_urls(self) -> list[str]:
        """Return a list of article URLs to potentially scrape."""

    def scrape(self, existing_keys: set[str]):
        """Yield articles one at a time for this source.

        *existing_keys* contains url_key values already in the DB so we skip them (FR-7).
        Returns a generator so callers can insert articles incrementally.
        """
        urls = self.discover_article_urls()
        try:
            for url in urls:
                key = self.url_key(url)
                if key in existing_keys:
                    continue
                try:
                    article = self.parse_article_page(url)
                    yield article
                except Exception as exc:
                    log.error("article_scrape_failed", url=url, error=str(exc))
                    yield Article(
                        url=url,
                        url_key=key,
                        title="",
                        source_name=self.source_name,
                        status="error",
                        error_message=str(exc),
                    )
        finally:
            self.close_browser()
