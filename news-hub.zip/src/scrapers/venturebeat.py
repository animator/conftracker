"""Scraper for venturebeat.com."""

from __future__ import annotations

from models import Article
from scrapers.base import BaseScraper


class VentureBeatScraper(BaseScraper):
    source_name = "venturebeat"
    base_url = "https://venturebeat.com"
    collection_name = "venturebeat"

    FEED_URL = "https://venturebeat.com/feed/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()

    def parse_article_page(self, url: str) -> Article:
        """VentureBeat blocks bot user-agents; use Playwright to render."""
        html = self.fetch_rendered(url, wait_selector="h1")
        return self._parse_html(url, html)
