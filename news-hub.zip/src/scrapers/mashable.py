"""Scraper for mashable.com."""

from __future__ import annotations

from models import Article
from scrapers.base import BaseScraper


class MashableScraper(BaseScraper):
    source_name = "mashable"
    base_url = "https://mashable.com"
    collection_name = "mashable"

    FEED_URL = "https://mashable.com/feeds/rss/all"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()

    def parse_article_page(self, url: str) -> Article:
        """Mashable blocks bot user-agents; use Playwright to render."""
        html = self.fetch_rendered(url, wait_selector="h1")
        return self._parse_html(url, html)
