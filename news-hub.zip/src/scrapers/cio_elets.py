"""Scraper for CIO Elets."""

from __future__ import annotations

from scrapers.base import BaseScraper


class CioEletsScraper(BaseScraper):
    source_name = "cio_elets"
    base_url = "https://cio.eletsonline.com"
    collection_name = "cio_elets"

    FEED_URL = "https://cio.eletsonline.com/feed/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
