"""Scraper for CIO Elets.

The RSS feed already includes the article description, full body, author,
categories, publication date, and image URL, so scraping builds records
directly from feed entries.
"""

from __future__ import annotations

from typing import Any

from bs4 import BeautifulSoup

from logger import get_logger, log_scrape_start_summary
from models import Article
from scrapers.base import FeedBasedScraper

log = get_logger(__name__)


class CioEletsScraper(FeedBasedScraper):
    source_name = "cio_elets"
    base_url = "https://cio.eletsonline.com"
    collection_name = "cio_elets"

    FEED_URL = "https://cio.eletsonline.com/feed/"

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)
        image_url = self._feed_image_url(entry)
        og_bytes, og_mime = self._download_image(image_url)

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=self._feed_author(entry),
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=self._clean_body(entry),
            description=self._clean_description(entry),
            source_name=self.source_name,
        )

    def _feed_author(self, entry: Any) -> str | None:
        authors = entry.get("authors") or []
        names = [author.get("name", "").strip()
                 for author in authors if author.get("name")]
        if names:
            return ", ".join(names)

        author = (entry.get("author") or "").strip()
        return author or None

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _feed_image_url(self, entry: Any) -> str | None:
        for media in entry.get("media_content", []):
            url = (media.get("url") or "").strip()
            if url:
                return url

        for enclosure in entry.get("enclosures", []):
            url = (enclosure.get("href") or enclosure.get("url") or "").strip()
            if url:
                return url

        return None

    def _clean_description(self, entry: Any) -> str:
        return self._clean_feed_html(entry.get("summary") or entry.get("description") or "")

    def _clean_body(self, entry: Any) -> str:
        fragments = entry.get("content") or []
        html = fragments[0].get("value", "") if fragments else ""
        if not html:
            html = entry.get("summary") or entry.get("description") or ""
        return self._clean_feed_html(html)

    def _clean_feed_html(self, html: str) -> str:
        if not html:
            return ""

        soup = BeautifulSoup(html, "lxml")
        for tag in soup.find_all(["script", "style", "iframe"]):
            tag.decompose()
        for paragraph in soup.find_all("p"):
            text = paragraph.get_text(" ", strip=True)
            if text.startswith("The post ") and "appeared first on" in text:
                paragraph.decompose()
        text = soup.get_text(separator="\n", strip=True)
        return text.strip()
