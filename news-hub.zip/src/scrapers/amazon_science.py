"""Scraper for Amazon Science blog."""

from __future__ import annotations

from scrapers.base import BaseScraper


class AmazonScienceScraper(BaseScraper):
    source_name = "amazon_science"
    base_url = "https://www.amazon.science"
    collection_name = "amazon_science"

    FEED_URL = "https://www.amazon.science/index.rss"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
