"""Scraper for Amazon Science blog.

The RSS feed already includes the article title, description, body, and
published date, so scraping builds records from feed entries and fetches the
article page only to resolve the og:image.
"""

from __future__ import annotations

from typing import Any

from bs4 import BeautifulSoup

from logger import get_logger, log_scrape_start_summary
from models import Article
from scrapers.base import FeedBasedScraper

log = get_logger(__name__)


class AmazonScienceScraper(FeedBasedScraper):
    source_name = "amazon_science"
    base_url = "https://www.amazon.science"
    collection_name = "amazon_science"

    FEED_URL = "https://www.amazon.science/index.rss"

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)
        og_bytes, og_mime = self._fetch_feed_image(entry.get("link", ""))

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=self._feed_author(entry),
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=self._clean_feed_body(entry),
            description=(entry.get("summary") or entry.get(
                "description") or "").strip(),
            source_name=self.source_name,
        )

    def _feed_author(self, entry: Any) -> str | None:
        author = (entry.get("author") or "").strip()
        return author or None

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _clean_feed_body(self, entry: Any) -> str:
        fragments = entry.get("content") or []
        html = fragments[0].get("value", "") if fragments else ""
        if not html:
            html = entry.get("summary") or entry.get("description") or ""
        if not html:
            return ""

        soup = BeautifulSoup(html, "lxml")
        for tag in soup.find_all(["script", "style", "iframe"]):
            tag.decompose()
        return soup.get_text(separator="\n", strip=True)

    def _fetch_feed_image(self, url: str) -> tuple[bytes | None, str | None]:
        if not url:
            return None, None

        try:
            resp = self.fetch(url)
        except Exception as exc:
            log.warning("amazon_science_page_fetch_failed",
                        url=url, error=str(exc))
            return None, None

        soup = BeautifulSoup(resp.text, "lxml")
        jld = self._parse_json_ld(soup) or {}
        image_url = jld.get("image") or self._og_meta(soup, "og:image") or ""
        if isinstance(image_url, dict):
            image_url = image_url.get("url", "")
        if isinstance(image_url, list):
            image_url = image_url[0] if image_url else ""

        return self._download_image(image_url or None)
