"""Scraper for theverge.com."""

from __future__ import annotations

from models import Article
from scrapers.base import BaseScraper


class TheVergeScraper(BaseScraper):
    source_name = "theverge"
    base_url = "https://www.theverge.com"
    collection_name = "theverge"

    FEED_URL = "https://www.theverge.com/rss/index.xml"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()

    def parse_article_page(self, url: str) -> Article:
        """The Verge blocks bot user-agents; use Playwright to render."""
        html = self.fetch_rendered(url, wait_selector="h1")
        return self._parse_html(url, html)
