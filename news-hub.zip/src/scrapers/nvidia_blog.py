"""Scraper for blogs.nvidia.com.

The RSS feed provides the article title, author, publication date, tags,
summary, full article HTML, and image metadata, so scraping builds records
directly from feed entries without visiting article pages.
"""

from __future__ import annotations

import re
from typing import Any

from bs4 import BeautifulSoup

from models import Article
from scrapers.base import FeedBasedScraper


class NvidiaBlogScraper(FeedBasedScraper):
    source_name = "nvidia_blog"
    base_url = "https://blogs.nvidia.com"
    collection_name = "nvidia_blog"

    FEED_URL = "https://blogs.nvidia.com/feed/"

    def parse_article_page(self, url: str) -> Article:
        raise NotImplementedError(
            f"{self.__class__.__name__} is feed-only and does not parse individual article pages: {url}"
        )

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)
        og_bytes, og_mime = self._download_image(self._feed_image_url(entry))

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=self._feed_author(entry),
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=self._clean_body(entry),
            description=(entry.get("summary") or entry.get(
                "description") or "").strip(),
            source_name=self.source_name,
        )

    def _feed_author(self, entry: Any) -> str | None:
        authors = entry.get("authors") or []
        names = [author.get("name", "").strip()
                 for author in authors if author.get("name")]
        if names:
            return ", ".join(names)

        author = (entry.get("author") or "").strip()
        return author or None

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _feed_image_url(self, entry: Any) -> str | None:
        for media in entry.get("media_thumbnail", []):
            url = (media.get("url") or "").strip()
            if url:
                return url

        for media in entry.get("media_content", []):
            url = (media.get("url") or "").strip()
            if url:
                return url

        for enclosure in entry.get("enclosures", []):
            url = (enclosure.get("href") or enclosure.get("url") or "").strip()
            if url:
                return url

        return None

    def _clean_body(self, entry: Any) -> str:
        fragments = entry.get("content") or []
        html = fragments[0].get("value", "") if fragments else ""
        if not html:
            html = entry.get("summary") or entry.get("description") or ""
        if not html:
            return ""

        soup = BeautifulSoup(html, "lxml")
        for tag in soup.find_all(["script", "style", "iframe"]):
            tag.decompose()

        marker = soup.find(id="bsf_rt_marker")
        if marker is not None:
            marker.decompose()

        blocks: list[str] = []
        for tag in soup.find_all(["p", "li", "h2", "h3", "h4", "blockquote"]):
            text = self._normalize_text(tag.get_text(" ", strip=True))
            if text:
                blocks.append(text)

        if blocks:
            return "\n".join(blocks)
        return self._normalize_text(soup.get_text(" ", strip=True))

    def _normalize_text(self, text: str) -> str:
        text = re.sub(r"\s+([,.;:!?])", r"\1", text)
        return re.sub(r"\s+", " ", text).strip()
