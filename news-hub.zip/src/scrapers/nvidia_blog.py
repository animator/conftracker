"""Scraper for blogs.nvidia.com."""

from __future__ import annotations

from scrapers.base import BaseScraper


class NvidiaBlogScraper(BaseScraper):
    source_name = "nvidia_blog"
    base_url = "https://blogs.nvidia.com"
    collection_name = "nvidia_blog"

    FEED_URL = "https://blogs.nvidia.com/feed/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
