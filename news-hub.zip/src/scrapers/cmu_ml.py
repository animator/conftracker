"""Scraper for CMU ML blog."""

from __future__ import annotations

from scrapers.base import BaseScraper


class CmuMlScraper(BaseScraper):
    source_name = "cmu_ml"
    base_url = "https://blog.ml.cmu.edu"
    collection_name = "cmu_ml"

    FEED_URL = "https://blog.ml.cmu.edu/feed/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
