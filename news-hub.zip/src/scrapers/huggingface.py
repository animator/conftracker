"""Scraper for huggingface.co trending models."""

from __future__ import annotations

from datetime import datetime, timezone

from logger import log_scrape_start_summary
from scrapers.base import BaseScraper, log


class HuggingFaceArticle:
    def __init__(self, data: dict):
        self._data = data
        self.url = data.get("url")
        self.title = data.get("title")

    def to_dict(self):
        return self._data


class HuggingfaceTrendingScraper(BaseScraper):
    source_name = "huggingface"
    base_url = "https://huggingface.co"
    collection_name = "huggingface"

    def discover_article_urls(self) -> list[str]:
        # Not used because we override scrape()
        return []

    def scrape(self, existing_keys: set[str]):
        resp = self.fetch(
            "https://huggingface.co/api/models?sort=trendingScore&limit=20")
        data = resp.json()
        self.last_discovered_url_count = len(data)
        log_scrape_start_summary(
            self.source_name, self.last_discovered_url_count)

        for item in data:
            model_id = item.get("id")
            if not model_id:
                continue

            url = f"https://huggingface.co/{model_id}"
            key = self.url_key(url)

            if key in existing_keys:
                continue

            try:
                # Extract title and author from id
                parts = model_id.split("/")
                if len(parts) == 2:
                    author = parts[0]
                    title = parts[1]
                else:
                    author = None
                    title = model_id

                # Extract license from tags
                tags = item.get("tags", [])
                license_val = None
                for tag in tags:
                    if tag.startswith("license:"):
                        license_val = tag.split(":", 1)[1]
                        break

                # Parse date
                created_at = item.get("createdAt")
                published_date = None
                if created_at:
                    try:
                        if created_at.endswith("Z"):
                            created_at = created_at[:-1] + "+00:00"
                        published_date = datetime.fromisoformat(created_at)
                    except ValueError:
                        pass

                # Fetch body (markdown content)
                body = None
                raw_url = f"https://huggingface.co/{model_id}/raw/main/README.md"
                try:
                    readme_resp = self.fetch(raw_url)
                    body = readme_resp.text
                except Exception as e:
                    log.warning("huggingface_readme_fetch_failed",
                                url=raw_url, error=str(e))

                doc = {
                    "url": url,
                    "url_key": key,
                    "title": title,
                    "author": author,
                    "tags": tags,
                    "published_date": published_date,
                    "body": body,
                    "description": None,
                    "source_name": self.source_name,
                    "scraped_at": datetime.now(timezone.utc),
                    "error_message": None,
                    "likes": item.get("likes"),
                    "trending_score": item.get("trendingScore"),
                    "downloads": item.get("downloads"),
                    "license": license_val,
                    "status": "ok",
                    "selected": None
                }

                yield HuggingFaceArticle(doc)

            except Exception as exc:
                log.error("huggingface_scrape_failed", url=url, error=str(exc))
                yield HuggingFaceArticle({
                    "url": url,
                    "url_key": key,
                    "title": model_id,
                    "source_name": self.source_name,
                    "status": "error",
                    "error_message": str(exc),
                })
