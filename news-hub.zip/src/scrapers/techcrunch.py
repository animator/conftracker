"""Scraper for techcrunch.com."""

from __future__ import annotations

from scrapers.base import BaseScraper


class TechCrunchScraper(BaseScraper):
    source_name = "techcrunch"
    base_url = "https://techcrunch.com"
    collection_name = "techcrunch"

    FEED_URL = "https://techcrunch.com/feed/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
