"""Scraper for Google Research blog."""

from __future__ import annotations

from scrapers.base import BaseScraper


class GoogleResearchScraper(BaseScraper):
    source_name = "google_research"
    base_url = "https://research.google"
    collection_name = "google_research"

    FEED_URL = "https://research.google/blog/rss/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
