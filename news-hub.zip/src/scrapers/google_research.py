"""Scraper for Google Research blog.

The RSS feed provides the article URL, publication date, tags, and image. The
article page provides the summary and full body content.
"""

from __future__ import annotations

from typing import Any

from bs4 import BeautifulSoup

from models import Article
from scrapers.base import FeedBasedScraper


class GoogleResearchScraper(FeedBasedScraper):
    source_name = "google_research"
    base_url = "https://research.google"
    collection_name = "google_research"

    FEED_URL = "https://research.google/blog/rss/"

    def _article_from_feed_entry(self, entry: Any, url_key: str) -> Article:
        published_date = self._feed_entry_published_date(entry)
        og_bytes, og_mime = self._download_image(self._feed_image_url(entry))
        description, body, author = self._fetch_page_content(
            entry.get("link", ""))

        return Article(
            url=entry.get("link", ""),
            url_key=url_key,
            title=(entry.get("title") or "").strip(),
            author=author,
            tags=self._feed_tags(entry),
            published_date=published_date,
            og_image=og_bytes,
            og_image_mimetype=og_mime,
            body=body,
            description=description,
            source_name=self.source_name,
        )

    def _feed_tags(self, entry: Any) -> list[str]:
        return [
            tag.get("term", "").strip()
            for tag in entry.get("tags", [])
            if tag.get("term") and tag.get("term", "").strip()
        ]

    def _feed_image_url(self, entry: Any) -> str | None:
        for media in entry.get("media_content", []):
            url = (media.get("url") or "").strip()
            if url:
                return url

        for media in entry.get("media_thumbnail", []):
            url = (media.get("url") or "").strip()
            if url:
                return url

        return None

    def _fetch_page_content(self, url: str) -> tuple[str, str, str | None]:
        resp = self.fetch(url)
        soup = BeautifulSoup(resp.text, "lxml")
        jld = self._parse_json_ld(soup) or {}

        summary = soup.select_one("div.blog-summary__summary")
        description = summary.get_text(" ", strip=True) if summary else ""
        if not description:
            description = (jld.get("description") or self._og_meta(
                soup, "og:description") or "").strip()

        body_container = soup.select_one("div.blog-detail-wrapper")
        body = ""
        if body_container:
            for unwanted in body_container.find_all(["script", "style", "iframe", "aside", "nav"]):
                unwanted.decompose()
            body = body_container.get_text(separator="\n", strip=True)

        author = self._extract_author(jld)
        return description.strip(), body.strip(), author
