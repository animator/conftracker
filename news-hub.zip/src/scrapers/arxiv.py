"""Scraper for arxiv.org — uses Atom/RSS feeds (FR-5)."""

from __future__ import annotations

import re
from datetime import datetime, timezone

import feedparser
from bs4 import BeautifulSoup

from logger import get_logger, log_scrape_start_summary
from models import Article
from scrapers.base import BaseScraper

log = get_logger(__name__)

FEED_URLS = [
    "https://export.arxiv.org/rss/cs.AI",
    "https://export.arxiv.org/rss/cs.LG",
    "https://export.arxiv.org/rss/cs.CL",
]


class ArxivScraper(BaseScraper):
    source_name = "arxiv"
    base_url = "https://export.arxiv.org"
    collection_name = "arxiv"

    def discover_article_urls(self) -> list[str]:
        """Not used directly — we override scrape() to parse the feed."""
        return []

    def _abs_url(self, link: str) -> str:
        """Ensure the link points to the abstract page."""
        # Handle /pdf/ or /abs/ links
        return re.sub(r"/pdf/", "/abs/", link).rstrip(".pdf")

    def _pdf_url(self, link: str) -> str:
        """Derive the PDF URL from an arxiv link."""
        abs_url = self._abs_url(link)
        return abs_url.replace("/abs/", "/pdf/")

    def _fetch_abstract(self, abs_url: str) -> str:
        """Fetch the full abstract from an arxiv abstract page."""
        try:
            resp = self.fetch(abs_url)
            soup = BeautifulSoup(resp.text, "lxml")
            block = soup.find("blockquote", class_="abstract")
            if block:
                # Remove the "Abstract:" heading span
                heading = block.find("span", class_="descriptor")
                if heading:
                    heading.decompose()
                return block.get_text(strip=True)
        except Exception as exc:
            log.warning("arxiv_abstract_fetch_failed",
                        url=abs_url, error=str(exc))
        return ""

    def scrape(self, existing_keys: set[str]):
        seen_keys: set[str] = set()

        # Collect entries from all feeds, then sort by date (newest first)
        all_entries: list[tuple] = []  # (entry, abs_url, key)
        for feed_url in FEED_URLS:
            try:
                resp = self.fetch(feed_url)
                feed = feedparser.parse(resp.text)
            except Exception as exc:
                log.error("arxiv_feed_failed", url=feed_url, error=str(exc))
                continue

            for entry in feed.entries:
                link = entry.get("link", "")
                if not link:
                    continue
                link = link.replace("http://", "https://")
                abs_url = self._abs_url(link)
                key = self.url_key(abs_url)
                if key in existing_keys or key in seen_keys:
                    continue
                seen_keys.add(key)
                all_entries.append((entry, abs_url, key))

        # Sort by published date descending so --limit fetches the most recent
        all_entries.sort(
            key=lambda t: t[0].get("published_parsed") or t[0].get(
                "updated_parsed") or (0,) * 9,
            reverse=True,
        )
        self.last_discovered_url_count = len(all_entries)
        log_scrape_start_summary(
            self.source_name, self.last_discovered_url_count)

        for entry, abs_url, key in all_entries:
            # Parse date
            published = entry.get(
                "published_parsed") or entry.get("updated_parsed")
            pub_dt = (
                datetime(*published[:6], tzinfo=timezone.utc)
                if published
                else None
            )

            # Authors
            authors = entry.get("authors", [])
            author_str = ", ".join(
                a.get("name", "") for a in authors) if authors else entry.get("author")

            # Tags / categories
            tags = [t.get("term", "")
                    for t in entry.get("tags", []) if t.get("term")]

            # Fetch full abstract from the paper page
            abstract = self._fetch_abstract(abs_url)

            # Derive links (no binary download)
            pdf_url = self._pdf_url(abs_url)

            yield Article(
                url=abs_url,
                url_key=key,
                title=entry.get("title", "").strip(),
                author=author_str,
                tags=tags,
                published_date=pub_dt,
                og_image=None,
                og_image_mimetype=None,
                pdf=None,
                pdf_mimetype=None,
                pdf_url=pdf_url,
                body=abstract,
                description=abstract[:500] if abstract else "",
                source_name=self.source_name,
            )
