"""Scraper for Open Source For U."""

from __future__ import annotations

from scrapers.base import BaseScraper


class OpenSourceForUScraper(BaseScraper):
    source_name = "opensourceforu"
    base_url = "https://www.opensourceforu.com"
    collection_name = "opensourceforu"

    FEED_URL = "https://www.opensourceforu.com/feed/"

    def discover_article_urls(self) -> list[str]:
        return self._discover_from_feed()
