"""Data models for articles and scrape runs."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class Article:
    url: str
    url_key: str  # unique key derived from URL
    title: str
    author: str | None = None
    tags: list[str] = field(default_factory=list)
    published_date: datetime | None = None
    og_image: bytes | None = None
    og_image_mimetype: str | None = None
    pdf: bytes | None = None
    pdf_mimetype: str | None = None
    pdf_url: str | None = None
    body: str | None = None
    description: str | None = None
    source_name: str = ""
    scraped_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc))
    status: str = "ok"  # "ok" | "error"
    error_message: str | None = None
    selected: bool = False

    def to_dict(self) -> dict[str, Any]:
        article = {
            "url": self.url,
            "url_key": self.url_key,
            "title": self.title,
            "author": self.author,
            "tags": self.tags,
            "published_date": self.published_date,
            "og_image": self.og_image,
            "og_image_mimetype": self.og_image_mimetype,
            "body": self.body,
            "description": self.description,
            "source_name": self.source_name,
            "scraped_at": self.scraped_at,
            "status": self.status,
            "error_message": self.error_message,
            "selected": self.selected,
        }

        if self.source_name == "arxiv":
            article.update({
                "pdf": self.pdf,
                "pdf_mimetype": self.pdf_mimetype,
                "pdf_url": self.pdf_url,
            })

        return article


@dataclass
class ScrapeRun:
    source: str
    start_time: datetime
    end_time: datetime | None = None
    articles_found: int = 0
    articles_inserted: int = 0
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "articles_found": self.articles_found,
            "articles_inserted": self.articles_inserted,
            "errors": self.errors,
        }
