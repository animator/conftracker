import sys
import feedparser
from datetime import datetime, timezone
from dateutil import parser as date_parser

sys.path.append('src')
from scrapers.registry import SCRAPER_CLASSES

for cls in SCRAPER_CLASSES:
    print(f"\nAnalyzing {cls.source_name}...")
    try:
        url = getattr(cls, 'FEED_URL', None)
        if url:
            feed = feedparser.parse(url)
            dates = []
            for entry in feed.entries[:10]:
                if hasattr(entry, 'published'):
                    dates.append(date_parser.parse(entry.published))
                elif hasattr(entry, 'updated'):
                    dates.append(date_parser.parse(entry.updated))
            
            if len(dates) >= 2:
                diffs = [(dates[i] - dates[i+1]).total_seconds() for i in range(len(dates)-1)]
                avg_diff_hrs = sum(diffs) / len(diffs) / 3600
                print(f"  - Avg time between posts: {avg_diff_hrs:.1f} hours")
                if avg_diff_hrs < 12:
                    print("  - Recommended Frequency: Every 2-4 hours")
                elif avg_diff_hrs < 48:
                    print("  - Recommended Frequency: Daily")
                else:
                    print("  - Recommended Frequency: Weekly")
            else:
                print("  - Not enough dates in feed.")
        else:
            print("  - No FEED_URL. Likely a custom scraper. Recommended: Daily")
    except Exception as e:
        print(f"  - Error: {e}")
