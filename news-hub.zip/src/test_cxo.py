import requests
from bs4 import BeautifulSoup

res = requests.get("https://www.cxodigitalpulse.com/")
soup = BeautifulSoup(res.text, "lxml")
links = set()
for a in soup.find_all("a", href=True):
    href = a["href"]
    if href.startswith("https://www.cxodigitalpulse.com/") and len(href.strip('/').split('/')) > 3:
        links.add(href)
for l in list(links)[:20]:
    print(l)
