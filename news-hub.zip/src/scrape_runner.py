"""Orchestrates a full scrape cycle across all registered sources."""

from __future__ import annotations

from datetime import datetime, timezone
from pymongo import DESCENDING
from db import ensure_indexes, get_db
from logger import get_logger
from models import ScrapeRun
from scrapers.base import BaseScraper
from scrapers.registry import SCRAPER_CLASSES, SCRAPER_CLASSES_WO_ARXIV

log = get_logger(__name__)


def _get_existing_keys(collection_name: str) -> set[str]:
    """Load all url_key values already stored for a source (FR-7)."""
    db = get_db()
    return {
        doc["url_key"]
        for doc in db[collection_name].find({}, {"url_key": 1, "_id": 0})
    }


def _run_single_source(scraper: BaseScraper, limit: int | None = None) -> None:
    """Scrape a single source end-to-end, recording a ScrapeRun (FR-10, FR-13)."""
    db = get_db()
    run = ScrapeRun(source=scraper.source_name,
                    start_time=datetime.now(timezone.utc))

    try:
        log.info("scrape_start", source=scraper.source_name)

        # Ensure per-source collection has a unique index on url_key (FR-8)
        collection = db[scraper.collection_name]
        collection.create_index("url_key", unique=True)
        collection.create_index([("published_date", DESCENDING)])

        existing_keys = _get_existing_keys(scraper.collection_name)
        found = 0
        inserted = 0
        for article in scraper.scrape(existing_keys):
            found += 1
            try:
                collection.insert_one(article.to_dict())
                inserted += 1
                log.info("db_insert_ok",
                         source=scraper.source_name,
                         url=article.url,
                         title=article.title[:80] if article.title else "")
            except Exception as exc:
                # Duplicate key or other write error — log and continue
                run.errors.append(f"{article.url}: {exc}")
                log.warning("db_insert_failed",
                            source=scraper.source_name,
                            url=article.url, error=str(exc))
            if limit is not None and inserted >= limit:
                break

        run.articles_found = found
        run.articles_inserted = inserted
        log.info(
            "scrape_complete",
            source=scraper.source_name,
            found=run.articles_found,
            inserted=run.articles_inserted,
        )
    except Exception as exc:
        run.errors.append(str(exc))
        log.error("scrape_source_failed",
                  source=scraper.source_name, error=str(exc))
    finally:
        run.end_time = datetime.now(timezone.utc)
        db["scrape_runs"].insert_one(run.to_dict())


def run_all(limit: int | None = None) -> None:
    """Execute a full scrape cycle for every registered source (FR-1, FR-13)."""
    log.info("cycle_start")
    ensure_indexes()

    for scraper_cls in SCRAPER_CLASSES_WO_ARXIV:
        try:
            scraper = scraper_cls()
            _run_single_source(scraper, limit=limit)
        except Exception as exc:
            # FR-15: persistent failure — log and continue
            log.error("scraper_init_failed",
                      source=scraper_cls.source_name, error=str(exc))

    log.info("cycle_complete")


def run_source(source_name: str, limit: int | None = None) -> None:
    """Run scraping for a single named source."""
    for scraper_cls in SCRAPER_CLASSES:
        if scraper_cls.source_name == source_name:
            ensure_indexes()
            _run_single_source(scraper_cls(), limit=limit)
            return
    raise ValueError(
        f"Unknown source: {source_name}. Available: {[s.source_name for s in SCRAPER_CLASSES]}")
