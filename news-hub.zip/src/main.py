"""CLI entry point for News Hub scraper (FR-12)."""

from __future__ import annotations

import re

import click

from logger import setup_logging


@click.group()
def cli() -> None:
    """News Hub — Daily News Scraper."""
    setup_logging()


def _get_live_urls(scraper: object) -> tuple[list[str], list[str]]:
    """Return ``(urls, warnings)`` for *scraper*'s current live feed.

    Handles three discovery strategies used across sources:
    - ``FEED_URL`` class attribute  → parse RSS/Atom via feedparser
    - ArxivScraper (module-level ``FEED_URLS`` list) → fetch + normalise URLs
    - Fallback → ``discover_article_urls()`` (e.g. sitemap-based sources)
    """
    import feedparser  # type: ignore[import]

    urls: list[str] = []
    warnings: list[str] = []
    cls = type(scraper)

    if hasattr(cls, "FEED_URL"):
        feed_url: str = cls.FEED_URL  # type: ignore[attr-defined]
        try:
            resp = scraper.fetch(feed_url)  # type: ignore[attr-defined]
            feed = feedparser.parse(resp.text)
            urls = [e.link for e in feed.entries if e.get("link")]
        except Exception as exc:
            warnings.append(f"Failed to fetch feed {feed_url}: {exc}")
        return urls, warnings

    # ArxivScraper overrides scrape() and uses a module-level FEED_URLS list
    if getattr(scraper, "source_name", None) == "arxiv":
        # type: ignore[import]
        from scrapers.arxiv import FEED_URLS as ARXIV_FEED_URLS

        seen: set[str] = set()
        for afeed_url in ARXIV_FEED_URLS:
            try:
                resp = scraper.fetch(afeed_url)  # type: ignore[attr-defined]
                feed = feedparser.parse(resp.text)
                for e in feed.entries:
                    link: str = e.get("link", "")
                    if not link:
                        continue
                    # Normalise identically to ArxivScraper._abs_url
                    link = link.replace("http://", "https://")
                    link = re.sub(r"/pdf/", "/abs/", link).rstrip(".pdf")
                    if link not in seen:
                        seen.add(link)
                        urls.append(link)
            except Exception as exc:
                warnings.append(
                    f"Failed to fetch arxiv feed {afeed_url}: {exc}")
        return urls, warnings

    # Fallback: sitemap or any other discover_article_urls() implementation
    try:
        urls = scraper.discover_article_urls()  # type: ignore[attr-defined]
    except Exception as exc:
        warnings.append(f"Failed to discover URLs: {exc}")
    return urls, warnings


def _get_live_feed_entries(scraper: object) -> tuple[list[tuple[str, datetime | None]], list[str]]:
    """Return ``([(url, published_date), ...], warnings)`` for the live feed.

    Similar to ``_get_live_urls`` but also extracts published dates from feed
    entries so callers can count articles newer than the last stored date.
    """
    import feedparser  # type: ignore[import]
    from datetime import datetime, timezone

    entries: list[tuple[str, datetime | None]] = []
    warnings: list[str] = []
    cls = type(scraper)

    def _feed_dt(entry: object) -> datetime | None:
        parsed = getattr(entry, "published_parsed", None) or getattr(
            entry, "updated_parsed", None)
        if parsed:
            return datetime(*parsed[:6], tzinfo=timezone.utc)
        return None

    if hasattr(cls, "FEED_URL"):
        feed_url: str = cls.FEED_URL  # type: ignore[attr-defined]
        try:
            resp = scraper.fetch(feed_url)  # type: ignore[attr-defined]
            feed = feedparser.parse(resp.text)
            entries = [(e.link, _feed_dt(e))
                       for e in feed.entries if e.get("link")]
        except Exception as exc:
            warnings.append(f"Failed to fetch feed {feed_url}: {exc}")
        return entries, warnings

    if getattr(scraper, "source_name", None) == "arxiv":
        from scrapers.arxiv import FEED_URLS as ARXIV_FEED_URLS

        seen: set[str] = set()
        for afeed_url in ARXIV_FEED_URLS:
            try:
                resp = scraper.fetch(afeed_url)  # type: ignore[attr-defined]
                feed = feedparser.parse(resp.text)
                for e in feed.entries:
                    link: str = e.get("link", "")
                    if not link:
                        continue
                    link = link.replace("http://", "https://")
                    link = re.sub(r"/pdf/", "/abs/", link).rstrip(".pdf")
                    if link not in seen:
                        seen.add(link)
                        entries.append((link, _feed_dt(e)))
            except Exception as exc:
                warnings.append(
                    f"Failed to fetch arxiv feed {afeed_url}: {exc}")
        return entries, warnings

    # Fallback: no date info available from sitemap-based discovery
    try:
        urls = scraper.discover_article_urls()  # type: ignore[attr-defined]
        entries = [(url, None) for url in urls]
    except Exception as exc:
        warnings.append(f"Failed to discover URLs: {exc}")
    return entries, warnings


@cli.command()
@click.option("-n", "--limit", type=int, default=None, help="Max number of recent articles to fetch per source.")
def run(limit: int | None) -> None:
    """Run a single scrape cycle across all sources (manual trigger)."""
    from scrape_runner import run_all

    run_all(limit=limit)


@cli.command()
@click.argument("source")
@click.option("-n", "--limit", type=int, default=None, help="Max number of recent articles to fetch.")
def run_source(source: str, limit: int | None) -> None:
    """Run scraping for a single SOURCE by name."""
    from scrape_runner import run_source as _run_source

    _run_source(source, limit=limit)


@cli.command()
def schedule() -> None:
    """Start the cron scheduler (default: every 2 hours)."""
    from scheduler import start_scheduler

    start_scheduler()


@cli.command("list-sources")
def list_sources() -> None:
    """Print all registered source names."""
    from scrapers.registry import SCRAPER_CLASSES

    for cls in SCRAPER_CLASSES:
        click.echo(cls.source_name)


@cli.command("check-new")
@click.option(
    "--source",
    "-s",
    default=None,
    help="Limit check to a single source by name (default: all sources).",
)
def check_new(source: str | None) -> None:
    """Report how many feed articles were published after the last stored article.

    For each source the command shows:
    \b
    - The most recently stored article title and its published date.
    - The number of articles currently returned by the live feed.
    - How many of those feed articles were published after the latest date in the DB.
    """
    from datetime import datetime, timezone
    from scrapers.base import BaseScraper
    from scrapers.registry import SCRAPER_CLASSES
    from db import get_db

    db = get_db()
    classes = list(SCRAPER_CLASSES)

    if source:
        classes = [c for c in classes if c.source_name == source]
        if not classes:
            click.echo(
                f"Unknown source: {source!r}. "
                "Use 'list-sources' to see available sources.",
                err=True,
            )
            raise click.Abort()

    rows: list[dict] = []
    all_warnings: list[tuple[str, str]] = []

    for cls in classes:
        scraper = cls()
        collection = db[cls.collection_name]

        # Most recently scraped article in the database
        latest = collection.find_one(
            {"status": "ok"},
            sort=[("published_date", -1)],
            projection={"title": 1, "url": 1,
                        "scraped_at": 1, "published_date": 1},
        )

        latest_date: datetime | None = None
        if latest:
            latest_date = latest.get(
                "published_date") or latest.get("scraped_at")

        # Fetch live feed entries with their published dates
        feed_entries, fetch_warnings = _get_live_feed_entries(scraper)

        # Count feed articles published after the last stored date
        if latest_date is not None:
            # Ensure latest_date is timezone-aware for comparison
            if latest_date.tzinfo is None:
                latest_date = latest_date.replace(tzinfo=timezone.utc)
            new_count = sum(
                1 for _, pub_dt in feed_entries
                if pub_dt is not None and pub_dt > latest_date
            )
        else:
            # No articles in DB yet — every feed entry is new
            new_count = len(feed_entries)

        click.echo(f"\nSource      : {cls.source_name}")
        if latest:
            date_str = latest_date.strftime(
                "%Y-%m-%d %H:%M UTC") if latest_date else "unknown"
            click.echo(f"Latest in DB: {latest.get('title', 'N/A')!r}")
            click.echo(f"Last updated: {date_str}")
        else:
            date_str = "—"
            click.echo("Latest in DB: (no articles stored yet)")
        click.echo(f"Feed total  : {len(feed_entries)}")
        click.echo(f"New articles: {new_count}")
        for w in fetch_warnings:
            click.echo(f"  [warn] {w}", err=True)
            all_warnings.append((cls.source_name, w))

        rows.append({
            "source": cls.source_name,
            "last_updated": date_str if latest else "—",
            "feed_total": len(feed_entries),
            "new_articles": new_count,
        })

    # ── Consolidated summary table ────────────────────────────────────────────
    if len(rows) > 1:
        click.echo("")
        headers = ("Source", "Last Updated", "Feed Total", "New Articles")
        col_source = max(len(headers[0]), max(len(r["source"]) for r in rows))
        col_date = max(len(headers[1]), max(
            len(r["last_updated"]) for r in rows))
        col_feed = max(len(headers[2]), max(
            len(str(r["feed_total"])) for r in rows))
        col_new = max(len(headers[3]), max(
            len(str(r["new_articles"])) for r in rows))

        sep = (
            f"+-{'-' * col_source}-+-{'-' * col_date}-+"
            f"-{'-' * col_feed}-+-{'-' * col_new}-+"
        )
        header_row = (
            f"| {headers[0]:<{col_source}} | {headers[1]:<{col_date}} |"
            f" {headers[2]:>{col_feed}} | {headers[3]:>{col_new}} |"
        )
        click.echo(sep)
        click.echo(header_row)
        click.echo(sep)
        for r in rows:
            click.echo(
                f"| {r['source']:<{col_source}} | {r['last_updated']:<{col_date}} |"
                f" {r['feed_total']:>{col_feed}} | {r['new_articles']:>{col_new}} |"
            )
        click.echo(sep)

    click.echo("")


@cli.command("build-selected")
def build_selected() -> None:
    """Combine articles from all sources (except arxiv) into 'selected_articles'.

    The collection is dropped and recreated on each run. Each document contains:
    title, description, image, image_mimetype, url, published_at — sorted
    descending by published_at.
    """
    from scrapers.registry import SCRAPER_CLASSES
    from db import get_db

    db = get_db()

    excluded = {"arxiv"}
    sources = [cls for cls in SCRAPER_CLASSES if cls.source_name not in excluded]

    projection = {
        "_id": 0,
        "title": 1,
        "description": 1,
        "og_image": 1,
        "og_image_mimetype": 1,
        "url": 1,
        "published_date": 1,
    }

    articles: list[dict] = []
    for cls in sources:
        collection = db[cls.collection_name]
        docs = collection.find({"selected": True}, projection)
        for doc in docs:
            articles.append(
                {
                    "title": doc.get("title"),
                    "description": doc.get("description"),
                    "og_image": doc.get("og_image"),
                    "og_image_mimetype": doc.get("og_image_mimetype"),
                    "url": doc.get("url"),
                    "published_date": doc.get("published_date"),
                    "source": cls.source_name,
                }
            )

    from datetime import datetime

    _min = datetime.min
    articles.sort(
        key=lambda a: (a["published_date"] or _min).replace(tzinfo=None),
        reverse=True,
    )

    target = db["selected_articles"]
    target.drop()
    if articles:
        target.insert_many(articles)

    click.echo(
        f"selected_articles rebuilt: {len(articles)} articles "
        f"from {len(sources)} sources."
    )


if __name__ == "__main__":
    cli()
