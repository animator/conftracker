"""Streamlit image gallery for og_images stored in MongoDB."""

from __future__ import annotations
from scrapers.registry import SCRAPER_CLASSES
from db import get_db, set_article_selected, delete_article

import base64
import sys
from pathlib import Path

import streamlit as st

# Make src/ importable when run via `streamlit run src/image_viewer.py`
sys.path.insert(0, str(Path(__file__).parent))


st.set_page_config(page_title="News Hub — Image Gallery", layout="wide")
st.title("News Hub — og_image Gallery")


def _toggle_selected(collection_name: str, article_id: object, key: str) -> None:
    """Callback: persist the checkbox state to MongoDB."""
    set_article_selected(collection_name, article_id, st.session_state[key])


def _delete_article(collection_name: str, article_id: object) -> None:
    """Callback: delete an article from MongoDB."""
    delete_article(collection_name, article_id)


SOURCE_MAP = {cls.source_name: cls for cls in SCRAPER_CLASSES}

# ── Sidebar filters ──────────────────────────────────────────────────────────
with st.sidebar:
    st.header("Filters")
    selected_source = st.selectbox("Source", ["(all)"] + list(SOURCE_MAP))
    limit = st.slider("Articles per source", 5, 500, 10)
    show_missing = st.checkbox("Show articles with no image", value=False)

db = get_db()
classes = (
    [SOURCE_MAP[selected_source]]
    if selected_source != "(all)"
    else list(SOURCE_MAP.values())
)

PLACEHOLDER_SVG = (
    "data:image/svg+xml;utf8,"
    "<svg xmlns='http://www.w3.org/2000/svg' width='300' height='160'>"
    "<rect width='300' height='160' fill='%23222'/>"
    "<text x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' "
    "fill='%23666' font-size='14' font-family='sans-serif'>No image</text>"
    "</svg>"
)

for cls in classes:
    collection = db[cls.collection_name]

    query: dict = {"status": "ok"}
    if not show_missing:
        query["og_image"] = {"$exists": True}

    docs = list(
        collection.find(
            query,
            {
                "title": 1,
                "url": 1,
                "og_image": 1,
                "og_image_mimetype": 1,
                "published_date": 1,
                "selected": 1,
            },
            sort=[("published_date", -1)],
            limit=limit,
        )
    )

    if not docs:
        continue

    with_image = sum(1 for d in docs if d.get("og_image"))
    st.subheader(f"{cls.source_name}  —  {with_image}/{len(docs)} with image")

    cols = st.columns(5)
    for i, doc in enumerate(docs):
        title = doc.get("title") or "Untitled"
        url = doc.get("url", "#")
        date = doc.get("published_date")
        date_str = date.strftime("%Y-%m-%d") if date else ""

        raw_image = doc.get("og_image")
        if raw_image:
            mime = doc.get("og_image_mimetype") or "image/jpeg"
            img_src = f"data:{mime};base64,{base64.b64encode(raw_image).decode()}"
            badge = ""
        else:
            img_src = PLACEHOLDER_SVG
            badge = " ⚠️ no image"

        with cols[i % 5]:
            st.markdown(
                f'<a href="{url}" target="_blank">'
                f'<img src="{img_src}" '
                f'style="width:100%;height:130px;object-fit:cover;border-radius:6px;"/>'
                f"</a>",
                unsafe_allow_html=True,
            )
            st.caption(f"[{title[:55]}...]({url})  \n{date_str}{badge}")
            cb_key = f"sel_{doc['_id']}"
            col_cb, col_del = st.columns([3, 1])
            with col_cb:
                st.checkbox(
                    "Select",
                    value=doc.get("selected", False),
                    key=cb_key,
                    on_change=_toggle_selected,
                    args=(cls.collection_name, doc["_id"], cb_key),
                )
            with col_del:
                st.button(
                    "🗑️",
                    key=f"del_{doc['_id']}",
                    on_click=_delete_article,
                    args=(cls.collection_name, doc["_id"]),
                    help="Delete article",
                )

    st.divider()
