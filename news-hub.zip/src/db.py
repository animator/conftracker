"""MongoDB connection and helpers."""

from __future__ import annotations

from pymongo import MongoClient
from pymongo.database import Database

from config import config

_client: MongoClient | None = None


def get_client() -> MongoClient:
    """Return a singleton MongoClient."""
    global _client
    if _client is None:
        _client = MongoClient(config.mongo_uri)
    return _client


def get_db() -> Database:
    """Return the application database."""
    return get_client()[config.mongo_db]


def ensure_indexes() -> None:
    """Create required indexes for all source collections and scrape_runs."""
    db = get_db()
    # scrape_runs collection index
    db["scrape_runs"].create_index("source")
    db["scrape_runs"].create_index("start_time")


def set_article_selected(collection_name: str, article_id: object, selected: bool) -> None:
    """Update the 'selected' field for a single article."""
    get_db()[collection_name].update_one(
        {"_id": article_id},
        {"$set": {"selected": selected}},
    )


def delete_article(collection_name: str, article_id: object) -> None:
    """Delete a single article by its _id."""
    get_db()[collection_name].delete_one({"_id": article_id})
